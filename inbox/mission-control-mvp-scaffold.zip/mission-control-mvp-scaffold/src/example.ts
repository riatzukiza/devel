import { assessThread, buildConnectionOpportunity } from './domain/reducer';
import { composeDashboardSnapshot } from './ui/panelMapping';
import { Personalization, SignalEvent, Thread } from './domain/types';

const profile: Personalization = {
  userId: 'user-1',
  geography: { country: 'US', region: 'AZ', metro: 'Phoenix' },
  expertiseTags: ['open-source-ai', 'ml-infra', 'typescript'],
  followedCommunities: ['oss-ai', 'local-dev', 'energy-watch'],
  savedProjects: ['gpu-cluster', 'local-inference'],
  preferredInterventionModes: ['research', 'code', 'ops'],
  federationTrustCircles: ['oss-ai', 'infra-mutual-aid'],
  sourceWeights: { official: 2.5, research: 2.3, individual: 1.0, community: 1.2 },
  agencyBias: 0.8,
  uncertaintyTolerance: 0.6,
  compressionResistance: 0.9,
  alertIntensity: 0.5,
};

const events: SignalEvent[] = [
  {
    id: 'event-1',
    version: 1,
    platform: 'bluesky',
    externalId: 'bsky-1',
    canonicalUrl: 'https://example.com/post/1',
    occurredAt: new Date().toISOString(),
    ingestedAt: new Date().toISOString(),
    author: {
      accountId: 'acct-1',
      handle: 'infra.watch',
      displayName: 'Infra Watch',
      sourceType: 'research',
      verified: true,
      labels: [],
    },
    content: {
      text: 'Grid instability reports are causing concern for GPU hosting regions.',
      language: 'en',
      links: [],
      mediaUrls: [],
      quotedExternalIds: [],
    },
    provenance: {
      firsthandness: 'synthesis',
      confidenceClass: 'medium',
      screenshotOnly: false,
      chain: [],
      trustCircleIds: ['oss-ai'],
      labelerFlags: [],
    },
    classification: {
      eventClass: ['infrastructure-stress'],
      narrativeClass: ['capacity-risk'],
      domainTags: ['energy', 'ml-infra'],
      geographyTags: ['US', 'AZ'],
      locality: 'regional',
      opportunityTags: ['local-inference', 'capacity-planning'],
      communityTags: ['oss-ai'],
    },
    engagement: {
      replies: 5,
      reposts: 7,
      likes: 20,
      upvotes: 0,
      voteVelocity: 0,
    },
    relationGraph: {
      quoteOfEventIds: [],
      corroboratingUrls: [],
    },
    dedupe: {
      lexicalHash: 'hash-1',
      mediaHashes: [],
    },
  },
];

const thread: Thread = {
  id: 'thread-1',
  version: 1,
  kind: 'event',
  status: 'active',
  title: 'Regional energy stress affecting AI infra capacity',
  summary: 'Energy volatility may reduce available inference and training capacity in nearby regions.',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  firstSeenAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString(),
  lastSeenAt: new Date().toISOString(),
  subject: {
    canonicalEntityIds: ['grid', 'gpu-hosting'],
    keywords: ['energy', 'capacity', 'hosting'],
    domainTags: ['energy', 'ml-infra', 'open-source-ai'],
    geographyTags: ['US', 'AZ', 'Phoenix'],
    communities: ['oss-ai', 'local-dev'],
    threatTags: ['grid-instability', 'hosting-risk'],
    opportunityTags: ['local-inference', 'capacity-planning'],
    laneHints: ['etaGlobal', 'localReach', 'piConnections'],
  },
  membership: {
    eventCount: 12,
    sampleEventIds: ['event-1'],
  },
  sourceDistribution: {
    byPlatform: { bluesky: 7, reddit: 5 },
    bySourceType: { research: 4, community: 6, individual: 2 },
    byFirsthandness: { commentary: 5, synthesis: 4, rumor: 1, official: 2 },
    byConfidenceClass: { medium: 8, high: 3, mixed: 1 },
  },
  confidence: {
    corroborationScore: 0.68,
    evidenceDiversity: 0.72,
    firsthandRatio: 0.36,
    officialRatio: 0.18,
    uncertainty: 0.34,
  },
  opportunitySignals: {
    actionablePosts: 4,
    resourceLinks: 3,
    collaboratingCommunities: ['oss-ai', 'infra-mutual-aid'],
    localActorsMentioned: 2,
    interventionModes: ['research', 'code', 'ops'],
  },
  relatedThreadIds: ['thread-2'],
};

const assessment = assessThread(thread, profile);
const opportunity = buildConnectionOpportunity(thread, assessment, profile);
const snapshot = composeDashboardSnapshot({
  profile,
  events,
  threads: [thread],
  assessments: [assessment],
  opportunities: opportunity ? [opportunity] : [],
});

console.log(JSON.stringify(snapshot, null, 2));
