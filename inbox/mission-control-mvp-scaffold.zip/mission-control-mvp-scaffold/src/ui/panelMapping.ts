import {
  ActionCard,
  ConnectionOpportunity,
  Personalization,
  ScoreRange,
  SignalEvent,
  Thread,
  ThreadAssessment,
} from '../domain/types';

const midpoint = (score: ScoreRange): number => (score.lower + score.upper) / 2;
const effortRank: Record<ActionCard['effort'], number> = { tiny: 0, small: 1, medium: 2, large: 3 };
const labelFromUnit = (value: number): ScoreRange['label'] => {
  if (value >= 0.85) return 'critical';
  if (value >= 0.65) return 'high';
  if (value >= 0.45) return 'elevated';
  if (value >= 0.25) return 'guarded';
  return 'low';
};

export interface HeroGaugeModel {
  id: 'agency' | 'nuance' | 'critical';
  label: string;
  score: ScoreRange;
  rationale: string[];
}

export interface CompositeStressClockModel {
  score: ScoreRange;
  uncertaintyGlow: number;
  sweepAmplitudeDeg: number;
  sweepPeriodMs: number;
  explanation: string;
}

export interface FirehoseItemModel {
  id: string;
  platform: SignalEvent['platform'];
  author: string;
  text: string;
  occurredAt: string;
  provenanceChip: string;
  confidenceChip: SignalEvent['provenance']['confidenceClass'];
  domainTags: string[];
}

export interface LaneCardModel {
  threadId: string;
  title: string;
  summary: string;
  score: ScoreRange;
  status: Thread['status'];
  tags: string[];
  sourceHealth: {
    provenance: ScoreRange;
    diversity: ScoreRange;
    rumorPressure: ScoreRange;
  };
  branches: Array<{
    id: string;
    label: string;
    realism: ScoreRange;
    actionability: ScoreRange;
    fearFactor: ScoreRange;
  }>;
}

export interface ConnectionLaneCardModel {
  id: string;
  threadId: string;
  title: string;
  summary: string;
  opportunityScore: ScoreRange;
  fitSummary: Array<{ key: string; value: number }>;
  actionCards: Array<Pick<ActionCard, 'id' | 'title' | 'summary' | 'effort' | 'interventionMode' | 'expectedBenefit' | 'risk'>>;
}

export interface ActionFeedItemModel {
  opportunityId: string;
  threadId: string;
  title: string;
  summary: string;
  effort: ActionCard['effort'];
  expectedBenefit: ScoreRange;
  risk: ScoreRange;
  interventionMode: ActionCard['interventionMode'];
}

export interface CriticalRailModel {
  threadId: string;
  title: string;
  disagreementIndex: ScoreRange;
  polarizationRisk: ScoreRange;
  compressionLoss: ScoreRange;
  topBranches: Array<{
    id: string;
    label: string;
    publicBenefit: ScoreRange;
    polarizationRisk: ScoreRange;
    compressionLoss: ScoreRange;
  }>;
}

export interface DashboardSnapshot {
  generatedAt: string;
  hero: {
    gauges: {
      agency: HeroGaugeModel;
      nuance: HeroGaugeModel;
      critical: HeroGaugeModel;
    };
    compositeStressClock: CompositeStressClockModel;
  };
  firehose: FirehoseItemModel[];
  lanes: {
    etaGlobal: LaneCardModel[];
    localReach: LaneCardModel[];
    piConnections: ConnectionLaneCardModel[];
  };
  actionFeed: ActionFeedItemModel[];
  criticalRails: CriticalRailModel[];
  controlsEcho: {
    agencyBias: number;
    uncertaintyTolerance: number;
    compressionResistance: number;
    alertIntensity: number;
    sourceWeights: Record<string, number>;
    federationTrustCircles: string[];
  };
}

function buildHeroGauges(
  assessments: ThreadAssessment[],
  opportunities: ConnectionOpportunity[],
): DashboardSnapshot['hero']['gauges'] {
  const agencyBase = opportunities.length
    ? opportunities.reduce((sum, item) => sum + midpoint(item.opportunityScore), 0) / opportunities.length / 100
    : 0.2;
  const nuanceBase = assessments.length
    ? assessments.reduce(
        (sum, item) =>
          sum +
          (midpoint(item.sourceHealth.sourceDiversity) * 0.35 +
            midpoint(item.disagreementIndex) * 0.25 +
            (100 - midpoint(item.compressionLoss)) * 0.4),
        0,
      ) /
      assessments.length /
      100
    : 0.2;
  const criticalBase = assessments.length
    ? assessments.reduce(
        (sum, item) =>
          sum +
          (midpoint(item.sourceHealth.provenanceStrength) * 0.35 +
            midpoint(item.sourceHealth.corroboration) * 0.35 +
            (100 - midpoint(item.sourceHealth.rumorPressure)) * 0.3),
        0,
      ) /
      assessments.length /
      100
    : 0.2;

  const agency: HeroGaugeModel = {
    id: 'agency',
    label: 'Agency',
    score: {
      lower: Math.max(0, Math.round((agencyBase - 0.08) * 100)),
      upper: Math.min(100, Math.round((agencyBase + 0.08) * 100)),
      label: labelFromUnit(agencyBase),
      uncertainty: 0.2,
      explanation: 'Bounded local action surfaced by Pi opportunities and reversible action cards.',
      drivers: [],
    },
    rationale: ['More ready opportunities raises agency.', 'Higher reversibility keeps the gauge honest.'],
  };

  const nuance: HeroGaugeModel = {
    id: 'nuance',
    label: 'Nuance',
    score: {
      lower: Math.max(0, Math.round((nuanceBase - 0.08) * 100)),
      upper: Math.min(100, Math.round((nuanceBase + 0.08) * 100)),
      label: labelFromUnit(nuanceBase),
      uncertainty: 0.15,
      explanation: 'Raised by source diversity and explicit disagreement, reduced by compression loss.',
      drivers: [],
    },
    rationale: ['Disagreement should stay visible.', 'Compression loss should stay low.'],
  };

  const critical: HeroGaugeModel = {
    id: 'critical',
    label: 'Critical',
    score: {
      lower: Math.max(0, Math.round((criticalBase - 0.08) * 100)),
      upper: Math.min(100, Math.round((criticalBase + 0.08) * 100)),
      label: labelFromUnit(criticalBase),
      uncertainty: 0.18,
      explanation: 'Raised by provenance and corroboration, reduced by rumor pressure.',
      drivers: [],
    },
    rationale: ['Use provenance to resist team-sport collapse.', 'Keep disconfirming evidence in view.'],
  };

  return { agency, nuance, critical };
}

function buildCompositeStressClock(assessments: ThreadAssessment[]): CompositeStressClockModel {
  const etaScores = assessments.map((item) => midpoint(item.laneScores.etaGlobalStress));
  const uncertainty = assessments.length
    ? assessments.reduce((sum, item) => sum + item.uncertaintyIndex.uncertainty, 0) / assessments.length
    : 0.2;
  const meanStress = etaScores.length ? etaScores.reduce((sum, value) => sum + value, 0) / etaScores.length : 20;
  return {
    score: {
      lower: Math.max(0, Math.round(meanStress - 8)),
      upper: Math.min(100, Math.round(meanStress + 8)),
      label: labelFromUnit(meanStress / 100),
      uncertainty,
      explanation: 'Weighted mean of eta Global stress across active thread assessments.',
      drivers: [],
    },
    uncertaintyGlow: Number(uncertainty.toFixed(2)),
    sweepAmplitudeDeg: Math.round((meanStress / 100) * 220),
    sweepPeriodMs: Math.max(2200, 6500 - Math.round(meanStress * 25)),
    explanation: 'Let the client animate the sweep continuously; only the amplitude and glow come from the backend.',
  };
}

function laneCard(thread: Thread, assessment: ThreadAssessment, lane: 'etaGlobal' | 'localReach'): LaneCardModel {
  const score = lane === 'etaGlobal' ? assessment.laneScores.etaGlobalStress : assessment.laneScores.localReach;
  return {
    threadId: thread.id,
    title: thread.title,
    summary: thread.summary,
    score,
    status: thread.status,
    tags: [...thread.subject.domainTags, ...thread.subject.geographyTags].slice(0, 6),
    sourceHealth: {
      provenance: assessment.sourceHealth.provenanceStrength,
      diversity: assessment.sourceHealth.sourceDiversity,
      rumorPressure: assessment.sourceHealth.rumorPressure,
    },
    branches: assessment.narrativeBranches.map((branch) => ({
      id: branch.id,
      label: branch.label,
      realism: branch.realism,
      actionability: branch.actionability,
      fearFactor: branch.fearFactor,
    })),
  };
}

function connectionCard(opportunity: ConnectionOpportunity): ConnectionLaneCardModel {
  return {
    id: opportunity.id,
    threadId: opportunity.threadId,
    title: opportunity.title,
    summary: opportunity.summary,
    opportunityScore: opportunity.opportunityScore,
    fitSummary: [
      { key: 'expertise', value: opportunity.fit.expertiseMatch },
      { key: 'community', value: opportunity.fit.communityMatch },
      { key: 'project', value: opportunity.fit.projectMatch },
      { key: 'geography', value: opportunity.fit.geographyMatch },
    ],
    actionCards: opportunity.actionCards.map((action) => ({
      id: action.id,
      title: action.title,
      summary: action.summary,
      effort: action.effort,
      interventionMode: action.interventionMode,
      expectedBenefit: action.expectedBenefit,
      risk: action.risk,
    })),
  };
}

function firehoseItems(events: SignalEvent[]): FirehoseItemModel[] {
  return events
    .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime())
    .slice(0, 16)
    .map((event) => ({
      id: event.id,
      platform: event.platform,
      author: event.author.displayName || event.author.handle,
      text: event.content.text,
      occurredAt: event.occurredAt,
      provenanceChip: event.provenance.firsthandness,
      confidenceChip: event.provenance.confidenceClass,
      domainTags: event.classification.domainTags.slice(0, 3),
    }));
}

function criticalRails(threads: Thread[], assessments: ThreadAssessment[]): CriticalRailModel[] {
  const threadMap = new Map(threads.map((thread) => [thread.id, thread]));
  return assessments
    .slice()
    .sort(
      (a, b) =>
        midpoint(b.polarizationRisk) + midpoint(b.compressionLoss) - midpoint(a.polarizationRisk) - midpoint(a.compressionLoss),
    )
    .slice(0, 4)
    .map((assessment) => {
      const thread = threadMap.get(assessment.threadId);
      return {
        threadId: assessment.threadId,
        title: thread?.title || assessment.threadId,
        disagreementIndex: assessment.disagreementIndex,
        polarizationRisk: assessment.polarizationRisk,
        compressionLoss: assessment.compressionLoss,
        topBranches: assessment.narrativeBranches.map((branch) => ({
          id: branch.id,
          label: branch.label,
          publicBenefit: branch.publicBenefit,
          polarizationRisk: branch.polarizationRisk,
          compressionLoss: branch.compressionLoss,
        })),
      };
    });
}

function actionFeed(opportunities: ConnectionOpportunity[]): ActionFeedItemModel[] {
  return opportunities
    .flatMap((opportunity) =>
      opportunity.actionCards.map((card) => ({
        opportunityId: opportunity.id,
        threadId: opportunity.threadId,
        title: card.title,
        summary: card.summary,
        effort: card.effort,
        expectedBenefit: card.expectedBenefit,
        risk: card.risk,
        interventionMode: card.interventionMode,
      })),
    )
    .sort((a, b) => {
      const delta = midpoint(b.expectedBenefit) - midpoint(a.expectedBenefit);
      if (delta !== 0) return delta;
      return effortRank[a.effort] - effortRank[b.effort];
    })
    .slice(0, 12);
}

export function composeDashboardSnapshot(params: {
  profile: Personalization;
  events: SignalEvent[];
  threads: Thread[];
  assessments: ThreadAssessment[];
  opportunities: ConnectionOpportunity[];
}): DashboardSnapshot {
  const { profile, events, threads, assessments, opportunities } = params;
  const threadMap = new Map(threads.map((thread) => [thread.id, thread]));

  const etaGlobal = assessments
    .slice()
    .sort((a, b) => midpoint(b.laneScores.etaGlobalStress) - midpoint(a.laneScores.etaGlobalStress))
    .slice(0, 6)
    .map((assessment) => laneCard(threadMap.get(assessment.threadId)!, assessment, 'etaGlobal'));

  const localReach = assessments
    .slice()
    .sort((a, b) => midpoint(b.laneScores.localReach) - midpoint(a.laneScores.localReach))
    .slice(0, 6)
    .map((assessment) => laneCard(threadMap.get(assessment.threadId)!, assessment, 'localReach'));

  const piConnections = opportunities
    .slice()
    .sort((a, b) => midpoint(b.opportunityScore) - midpoint(a.opportunityScore))
    .slice(0, 6)
    .map(connectionCard);

  return {
    generatedAt: new Date().toISOString(),
    hero: {
      gauges: buildHeroGauges(assessments, opportunities),
      compositeStressClock: buildCompositeStressClock(assessments),
    },
    firehose: firehoseItems(events),
    lanes: {
      etaGlobal,
      localReach,
      piConnections,
    },
    actionFeed: actionFeed(opportunities),
    criticalRails: criticalRails(threads, assessments),
    controlsEcho: {
      agencyBias: profile.agencyBias,
      uncertaintyTolerance: profile.uncertaintyTolerance,
      compressionResistance: profile.compressionResistance,
      alertIntensity: profile.alertIntensity,
      sourceWeights: profile.sourceWeights,
      federationTrustCircles: profile.federationTrustCircles,
    },
  };
}
