import {
  ActionCard,
  ConnectionOpportunity,
  GaugeDefinition,
  Personalization,
  ScoreRange,
  Thread,
  ThreadAssessment,
  ThreadFeatureVector,
} from './types';

export const GaugeDefinitions: Record<string, GaugeDefinition> = {
  agency: {
    id: 'agency',
    label: 'Agency',
    description: 'How much bounded local action the system can currently surface.',
    sourceKeys: ['piBridgeOpportunity', 'actionability', 'networkMatch', 'reversibility'],
    thresholds: [
      { label: 'low', min: 0 },
      { label: 'guarded', min: 25 },
      { label: 'elevated', min: 45 },
      { label: 'high', min: 65 },
      { label: 'critical', min: 85 },
    ],
  },
  nuance: {
    id: 'nuance',
    label: 'Nuance',
    description: 'How well the system preserves disagreement and resists compression.',
    sourceKeys: ['sourceDiversity', 'disagreementIndex', 'compressionLoss'],
    thresholds: [
      { label: 'low', min: 0 },
      { label: 'guarded', min: 25 },
      { label: 'elevated', min: 45 },
      { label: 'high', min: 65 },
      { label: 'critical', min: 85 },
    ],
  },
  critical: {
    id: 'critical',
    label: 'Critical',
    description: 'How strong the provenance and disconfirming evidence posture is right now.',
    sourceKeys: ['provenanceStrength', 'corroboration', 'rumorPressure'],
    thresholds: [
      { label: 'low', min: 0 },
      { label: 'guarded', min: 25 },
      { label: 'elevated', min: 45 },
      { label: 'high', min: 65 },
      { label: 'critical', min: 85 },
    ],
  },
  compositeStress: {
    id: 'compositeStress',
    label: 'Composite Stress',
    description: 'Credible global stress weighted by freshness, corroboration, and threat intensity.',
    sourceKeys: ['etaGlobalStress', 'uncertaintyIndex'],
    thresholds: [
      { label: 'low', min: 0 },
      { label: 'guarded', min: 25 },
      { label: 'elevated', min: 45 },
      { label: 'high', min: 65 },
      { label: 'critical', min: 85 },
    ],
  },
};

const clamp01 = (value: number): number => Math.max(0, Math.min(1, value));
const average = (values: number[]): number => {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
};
const sumRecord = (record: Record<string, number>): number => Object.values(record).reduce((sum, value) => sum + value, 0);
const overlapScore = (a: string[], b: string[]): number => {
  if (!a.length || !b.length) return 0;
  const right = new Set(b.map((item) => item.toLowerCase()));
  const matches = a.filter((item) => right.has(item.toLowerCase())).length;
  return clamp01(matches / Math.max(1, Math.min(a.length, b.length)));
};
const normCount = (count: number, saturation: number): number => clamp01(count / saturation);
const hoursBetween = (leftIso: string, right: Date): number => Math.abs(right.getTime() - new Date(leftIso).getTime()) / 36e5;

function labelFor(percent: number): ScoreRange['label'] {
  if (percent >= 85) return 'critical';
  if (percent >= 65) return 'high';
  if (percent >= 45) return 'elevated';
  if (percent >= 25) return 'guarded';
  return 'low';
}

function intervalFromValue(
  rawValue: number,
  uncertainty: number,
  explanation: string,
  drivers: ScoreRange['drivers'] = [],
): ScoreRange {
  const center = clamp01(rawValue);
  const spread = 0.08 + clamp01(uncertainty) * 0.22;
  const lower = Math.round(Math.max(0, center - spread / 2) * 100);
  const upper = Math.round(Math.min(1, center + spread / 2) * 100);
  const midpoint = Math.round(((lower + upper) / 2));
  return {
    lower,
    upper,
    label: labelFor(midpoint),
    uncertainty: Number(clamp01(uncertainty).toFixed(2)),
    explanation,
    drivers,
  };
}

function ratio(record: Record<string, number>, key: string, total: number): number {
  if (!total) return 0;
  return clamp01((record[key] ?? 0) / total);
}

export function extractThreadFeatures(
  thread: Thread,
  profile: Personalization,
  now: Date = new Date(),
): ThreadFeatureVector {
  const totalEvents = Math.max(1, thread.membership.eventCount || sumRecord(thread.sourceDistribution.byPlatform));
  const commentaryRatio = ratio(thread.sourceDistribution.byFirsthandness, 'commentary', totalEvents);
  const rumorRatio = ratio(thread.sourceDistribution.byFirsthandness, 'rumor', totalEvents);
  const ageHours = hoursBetween(thread.lastSeenAt, now);
  const recency = clamp01(1 - ageHours / 72);
  const volume = normCount(thread.membership.eventCount, 80);

  const userGeo = [profile.geography.country, profile.geography.region, profile.geography.metro].filter(Boolean) as string[];
  const domainInterest = [...profile.expertiseTags, ...profile.savedProjects];
  const communityInterest = [...profile.followedCommunities, ...profile.federationTrustCircles];

  const domainMatch = average([
    overlapScore(thread.subject.domainTags, domainInterest),
    overlapScore(thread.subject.opportunityTags, domainInterest),
  ]);
  const networkMatch = average([
    overlapScore(thread.subject.communities, communityInterest),
    overlapScore(thread.opportunitySignals.collaboratingCommunities, communityInterest),
  ]);
  const geoProximity = overlapScore(thread.subject.geographyTags, userGeo);
  const interventionModeMatch = overlapScore(thread.opportunitySignals.interventionModes, profile.preferredInterventionModes);

  const actionability = clamp01(
    normCount(thread.opportunitySignals.actionablePosts, 10) * 0.35 +
      normCount(thread.opportunitySignals.resourceLinks, 8) * 0.2 +
      normCount(thread.opportunitySignals.localActorsMentioned, 8) * 0.2 +
      interventionModeMatch * 0.25,
  );

  const provenanceStrength = clamp01(
    thread.confidence.firsthandRatio * 0.3 +
      thread.confidence.officialRatio * 0.2 +
      thread.confidence.corroborationScore * 0.3 +
      thread.confidence.evidenceDiversity * 0.2,
  );

  const corroboration = clamp01(thread.confidence.corroborationScore);
  const sourceDiversity = clamp01(thread.confidence.evidenceDiversity);
  const uncertainty = clamp01(thread.confidence.uncertainty * 0.7 + rumorRatio * 0.3);
  const noveltyVelocity = clamp01(recency * 0.6 + volume * 0.4);
  const fearFactor = clamp01(normCount(thread.subject.threatTags.length, 5) * 0.65 + uncertainty * 0.35);
  const polarizationRisk = clamp01(
    commentaryRatio * 0.35 +
      rumorRatio * 0.2 +
      (thread.kind === 'narrative' ? 0.2 : 0.05) +
      fearFactor * 0.15 +
      (1 - sourceDiversity) * 0.1,
  );
  const compressionLoss = clamp01(
    normCount(thread.subject.domainTags.length + thread.subject.communities.length + thread.relatedThreadIds.length, 12) * 0.55 +
      (1 - sourceDiversity) * 0.25 +
      commentaryRatio * 0.2,
  );
  const publicBenefit = clamp01(
    provenanceStrength * 0.35 + sourceDiversity * 0.25 + actionability * 0.2 + (1 - polarizationRisk) * 0.2,
  );
  const collaboratorAvailability = clamp01(
    networkMatch * 0.55 + normCount(thread.opportunitySignals.collaboratingCommunities.length, 6) * 0.25 + interventionModeMatch * 0.2,
  );

  return {
    noveltyVelocity,
    provenanceStrength,
    corroboration,
    sourceDiversity,
    uncertainty,
    geoProximity,
    domainMatch,
    networkMatch,
    actionability,
    publicBenefit,
    fearFactor,
    polarizationRisk,
    compressionLoss,
    collaboratorAvailability,
  };
}

function buildBranches(thread: Thread, features: ThreadFeatureVector): ThreadAssessment['narrativeBranches'] {
  const sharedSupport = [{ eventId: thread.membership.sampleEventIds[0] ?? 'sample-0', role: 'supporting', note: 'Representative member event', weight: 0.5 }] as const;
  const sharedDisconfirm = [{ eventId: thread.membership.sampleEventIds[1] ?? 'sample-1', role: 'disconfirming', note: 'Representative counter-signal', weight: 0.4 }] as const;

  return [
    {
      id: `${thread.id}:stabilize`,
      label: 'Stabilization branch',
      description: 'Signals resolve into a narrower, better-corroborated understanding with lower panic pressure.',
      horizon: 'days',
      realism: intervalFromValue(features.corroboration * 0.55 + (1 - features.fearFactor) * 0.2 + features.sourceDiversity * 0.25, features.uncertainty, 'Most plausible when corroboration keeps improving.'),
      fearFactor: intervalFromValue(features.fearFactor * 0.35, features.uncertainty, 'Emotional destabilization should drop if corroboration rises.'),
      publicBenefit: intervalFromValue(features.publicBenefit * 0.9, features.uncertainty, 'This branch improves collective reasoning by reducing rumor share.'),
      actionability: intervalFromValue(features.actionability * 0.7 + 0.15, features.uncertainty, 'Useful for instrumenting the thread and checking key claims.'),
      polarizationRisk: intervalFromValue(features.polarizationRisk * 0.45, features.uncertainty, 'Camp formation is lower when disconfirming evidence remains visible.'),
      compressionLoss: intervalFromValue(features.compressionLoss * 0.4, features.uncertainty, 'Nuance survives better in this branch.'),
      watchSignals: ['More firsthand reporting', 'Independent confirmation', 'Reduced quote-chain dominance'],
      supportingEvidence: [...sharedSupport],
      disconfirmingEvidence: [...sharedDisconfirm],
    },
    {
      id: `${thread.id}:escalate`,
      label: 'Escalation branch',
      description: 'Attention accelerates faster than verification and the thread becomes more destabilizing.',
      horizon: 'days',
      realism: intervalFromValue(features.noveltyVelocity * 0.35 + features.fearFactor * 0.35 + (1 - features.corroboration) * 0.3, features.uncertainty, 'More plausible when novelty outruns verification.'),
      fearFactor: intervalFromValue(features.fearFactor * 0.9 + 0.05, features.uncertainty, 'This branch carries the highest destabilization risk.'),
      publicBenefit: intervalFromValue(features.publicBenefit * 0.35, features.uncertainty, 'Amplifying this branch is mostly useful as a warning, not as a headline frame.'),
      actionability: intervalFromValue(features.actionability * 0.45, features.uncertainty, 'Action remains possible, but mainly around mitigation and verification.'),
      polarizationRisk: intervalFromValue(features.polarizationRisk * 0.85 + 0.05, features.uncertainty, 'Compression into camps becomes more likely in this branch.'),
      compressionLoss: intervalFromValue(features.compressionLoss * 0.85 + 0.05, features.uncertainty, 'Nuance gets squeezed out if this branch dominates.'),
      watchSignals: ['Commentary share rises', 'Rumor chains replicate', 'Same claims appear without new evidence'],
      supportingEvidence: [...sharedSupport],
      disconfirmingEvidence: [...sharedDisconfirm],
    },
    {
      id: `${thread.id}:local-response`,
      label: 'Constructive local response branch',
      description: 'The thread is translated into bounded local action, feedback collection, and shared instruments.',
      horizon: 'weeks',
      realism: intervalFromValue(features.actionability * 0.35 + features.networkMatch * 0.25 + features.collaboratorAvailability * 0.4, features.uncertainty, 'Most plausible when communities, projects, and modes already align.'),
      fearFactor: intervalFromValue(features.fearFactor * 0.4, features.uncertainty, 'Local action dampens helplessness even when stress remains real.'),
      publicBenefit: intervalFromValue(features.publicBenefit * 0.95 + 0.03, features.uncertainty, 'This branch is usually the healthiest one to amplify.'),
      actionability: intervalFromValue(features.actionability * 0.75 + features.networkMatch * 0.2, features.uncertainty, 'High if the user has a credible intervention surface.'),
      polarizationRisk: intervalFromValue(features.polarizationRisk * 0.4, features.uncertainty, 'Action posture lowers team-sport collapse.'),
      compressionLoss: intervalFromValue(features.compressionLoss * 0.45, features.uncertainty, 'The branch rewards concrete feedback over slogans.'),
      watchSignals: ['Action cards get completed', 'Feedback metrics move', 'New collaborators appear'],
      supportingEvidence: [...sharedSupport],
      disconfirmingEvidence: [...sharedDisconfirm],
    },
  ];
}

export function assessThread(
  thread: Thread,
  profile: Personalization,
  reducerVersion = 'mvp-v1',
  now: Date = new Date(),
): ThreadAssessment {
  const features = extractThreadFeatures(thread, profile, now);
  const totalEvents = Math.max(1, thread.membership.eventCount || sumRecord(thread.sourceDistribution.byPlatform));
  const commentaryRatio = ratio(thread.sourceDistribution.byFirsthandness, 'commentary', totalEvents);
  const rumorRatio = ratio(thread.sourceDistribution.byFirsthandness, 'rumor', totalEvents);

  const etaGlobalRaw = clamp01(
    features.fearFactor * 0.35 + features.noveltyVelocity * 0.25 + features.provenanceStrength * 0.2 + features.corroboration * 0.2,
  );
  const localReachRaw = clamp01(
    features.geoProximity * 0.35 + features.domainMatch * 0.3 + features.networkMatch * 0.15 + features.actionability * 0.2,
  );
  const piBridgeRaw = clamp01(
    features.actionability * 0.3 + features.domainMatch * 0.2 + features.networkMatch * 0.15 + features.collaboratorAvailability * 0.2 + features.publicBenefit * 0.15,
  );

  return {
    id: `${thread.id}:assessment:${reducerVersion}`,
    version: 1,
    threadId: thread.id,
    reducerVersion,
    computedAt: now.toISOString(),
    window: {
      startAt: thread.firstSeenAt,
      endAt: thread.lastSeenAt,
    },
    laneScores: {
      etaGlobalStress: intervalFromValue(
        etaGlobalRaw,
        features.uncertainty,
        'Credible global stress from threat intensity, freshness, and corroboration.',
        [
          { key: 'fearFactor', value: features.fearFactor * 2 - 1, note: 'Threat and destabilization content' },
          { key: 'noveltyVelocity', value: features.noveltyVelocity * 2 - 1, note: 'Attention acceleration and recency' },
          { key: 'provenanceStrength', value: features.provenanceStrength * 2 - 1, note: 'How grounded the thread is' },
        ],
      ),
      localReach: intervalFromValue(
        localReachRaw,
        features.uncertainty,
        'How much this thread sits inside the user\'s actual field of influence.',
        [
          { key: 'geoProximity', value: features.geoProximity * 2 - 1, note: 'Local geography overlap' },
          { key: 'domainMatch', value: features.domainMatch * 2 - 1, note: 'Expertise and project overlap' },
          { key: 'actionability', value: features.actionability * 2 - 1, note: 'Bounded steps already visible' },
        ],
      ),
      piBridgeOpportunity: intervalFromValue(
        piBridgeRaw,
        features.uncertainty,
        'How promising the bridge is from understanding to local action.',
        [
          { key: 'actionability', value: features.actionability * 2 - 1, note: 'Can the system suggest a move?' },
          { key: 'networkMatch', value: features.networkMatch * 2 - 1, note: 'Are collaborators already nearby?' },
          { key: 'publicBenefit', value: features.publicBenefit * 2 - 1, note: 'Will amplifying the action help?' },
        ],
      ),
    },
    sourceHealth: {
      provenanceStrength: intervalFromValue(features.provenanceStrength, features.uncertainty, 'Weighted mix of firsthandness, official ratio, corroboration, and evidence diversity.'),
      corroboration: intervalFromValue(features.corroboration, features.uncertainty, 'Independent confirmation across sources and formats.'),
      sourceDiversity: intervalFromValue(features.sourceDiversity, features.uncertainty, 'How many distinct source types and communities are represented.'),
      commentaryDominance: intervalFromValue(commentaryRatio, features.uncertainty, 'Higher means interpretation is outrunning original reporting.'),
      rumorPressure: intervalFromValue(rumorRatio, features.uncertainty, 'Higher means the thread needs stronger critical rails.'),
    },
    disagreementIndex: intervalFromValue(
      clamp01(features.sourceDiversity * 0.35 + commentaryRatio * 0.2 + normCount(thread.relatedThreadIds.length, 6) * 0.25 + (thread.kind === 'narrative' ? 0.2 : 0.05)),
      features.uncertainty,
      'Explicit disagreement is healthy when paired with evidence and branch separation.',
    ),
    uncertaintyIndex: intervalFromValue(
      features.uncertainty,
      features.uncertainty,
      'Uncertainty grows when rumor share is high or corroboration is still thin.',
    ),
    polarizationRisk: intervalFromValue(
      features.polarizationRisk,
      features.uncertainty,
      'High values mean the topic can collapse into partisan bins faster than it can be reasoned through.',
    ),
    compressionLoss: intervalFromValue(
      features.compressionLoss,
      features.uncertainty,
      'High values mean too much nuance gets discarded when one branch dominates the thread.',
    ),
    narrativeBranches: buildBranches(thread, features),
    reasoningSummary: [
      `${thread.title} is treated as a ${thread.kind} thread with ${thread.membership.eventCount} member events.`,
      `Global stress is driven most by ${thread.subject.threatTags.slice(0, 3).join(', ') || 'freshness and corroboration'}.`,
      `Local reach is driven by overlap with ${thread.subject.domainTags.slice(0, 3).join(', ') || 'user expertise and projects'}.`,
      `Pi opportunity rises when actionability and collaborator availability are both present.`,
    ],
    evidenceIndex: [
      {
        eventId: thread.membership.sampleEventIds[0] ?? 'sample-0',
        role: 'context',
        note: 'Representative event carried into the assessment.',
        weight: 0.5,
      },
    ],
  };
}

function makeActionCard(
  baseId: string,
  title: string,
  summary: string,
  interventionMode: ActionCard['interventionMode'],
  effort: ActionCard['effort'],
  explanation: string,
): ActionCard {
  return {
    id: baseId,
    title,
    summary,
    scope: effort === 'tiny' ? 'self' : 'network',
    effort,
    expectedBenefit: intervalFromValue(0.62, 0.2, explanation),
    risk: intervalFromValue(0.28, 0.15, 'Keep risk bounded, reversible, and measurable.'),
    reversibility: intervalFromValue(0.82, 0.1, 'Prefer actions that can be stopped or revised quickly.'),
    interventionMode,
    feedbackMetric: {
      key: 'feedback_delta',
      description: 'Did the action produce a new fact, a collaborator, or a measurable capacity gain?',
      targetDirection: 'up',
      observationWindowHours: 48,
    },
    prerequisites: [],
  };
}

export function buildConnectionOpportunity(
  thread: Thread,
  assessment: ThreadAssessment,
  profile: Personalization,
  now: Date = new Date(),
): ConnectionOpportunity | null {
  const piMidpoint = (assessment.laneScores.piBridgeOpportunity.lower + assessment.laneScores.piBridgeOpportunity.upper) / 200;
  if (piMidpoint < 0.4) return null;

  const expertiseMatch = overlapScore(thread.subject.domainTags, [...profile.expertiseTags, ...profile.savedProjects]);
  const communityMatch = overlapScore(thread.subject.communities, profile.followedCommunities);
  const geographyMatch = overlapScore(thread.subject.geographyTags, [profile.geography.country, profile.geography.region, profile.geography.metro].filter(Boolean) as string[]);
  const trustCircleMatch = overlapScore(thread.opportunitySignals.collaboratingCommunities, profile.federationTrustCircles);
  const projectMatch = overlapScore(thread.subject.opportunityTags, profile.savedProjects);

  const fit = {
    expertiseMatch,
    projectMatch,
    communityMatch,
    geographyMatch,
    trustCircleMatch,
  };

  const fitComposite = average(Object.values(fit));
  const opportunityScore = intervalFromValue(
    clamp01(piMidpoint * 0.6 + fitComposite * 0.4),
    assessment.uncertaintyIndex.uncertainty,
    'Composite of thread bridge score and user-specific fit.',
  );

  const dominantMode = thread.opportunitySignals.interventionModes[0] ?? profile.preferredInterventionModes[0] ?? 'research';

  const actionCards: ActionCard[] = [
    makeActionCard(
      `${thread.id}:verify`,
      'Add one disconfirming check',
      `Find one missing counter-source or primary source for ${thread.title}.`,
      'research',
      'tiny',
      'Improves the world-model before the thread hardens into a camp story.',
    ),
    makeActionCard(
      `${thread.id}:translate`,
      'Translate the thread into a bounded local note',
      'Turn the thread into a 5-sentence local brief with one measurable next step.',
      dominantMode,
      'small',
      'Creates shared situational awareness without importing team-sport framing.',
    ),
    makeActionCard(
      `${thread.id}:coordinate`,
      'Run one reversible coordination experiment',
      'Ask one relevant community or collaborator to test a small action hypothesis and report back.',
      dominantMode,
      'small',
      'Converts passive awareness into feedback-bearing action.',
    ),
  ];

  return {
    id: `${thread.id}:connection`,
    version: 1,
    threadId: thread.id,
    assessmentId: assessment.id,
    status: 'ready',
    title: `${thread.title}: local bridge opportunity`,
    summary: 'A candidate bridge from global understanding to one reversible local intervention.',
    globalNeed: thread.summary,
    localHypothesis: 'A user or network with matching expertise can improve either understanding or response capacity with a bounded step.',
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    fit,
    opportunityScore,
    targetGeographies: thread.subject.geographyTags,
    targetCommunities: thread.subject.communities,
    targetModes: thread.opportunitySignals.interventionModes.length ? thread.opportunitySignals.interventionModes : profile.preferredInterventionModes,
    collaboratingNodes: thread.opportunitySignals.collaboratingCommunities,
    actionCards,
    blockers: ['Needs one clearer feedback loop', 'Needs at least one named collaborator or community entry point'],
    risks: ['Premature certainty', 'Turning a live thread into identity theater'],
    feedbackPlan: {
      reviewAfterHours: 48,
      metrics: [
        {
          key: 'new_evidence',
          description: 'Count of new primary sources or disconfirming signals found after the action.',
          targetDirection: 'up',
          observationWindowHours: 48,
        },
        {
          key: 'capacity_delta',
          description: 'Did the action create new local capacity, instrumentation, or a live collaborator?',
          targetDirection: 'up',
          observationWindowHours: 72,
        },
      ],
      successDefinition: 'Within one or two days, the action produces either a better model or a small but real capacity gain.',
    },
  };
}
