import { z } from 'zod';

export const PlatformSchema = z.enum(['bluesky', 'reddit', 'rss', 'official', 'manual']);
export const SourceTypeSchema = z.enum(['individual', 'community', 'news', 'government', 'ngo', 'research', 'unknown']);
export const ConfidenceClassSchema = z.enum(['low', 'mixed', 'medium', 'high']);
export const FirsthandnessSchema = z.enum(['firsthand', 'commentary', 'rumor', 'synthesis', 'official']);
export const ThreadKindSchema = z.enum(['event', 'narrative', 'opportunity']);
export const ThreadStatusSchema = z.enum(['emerging', 'active', 'stabilizing', 'dormant', 'resolved']);
export const LaneSchema = z.enum(['etaGlobal', 'localReach', 'piConnections']);
export const ScoreLabelSchema = z.enum(['low', 'guarded', 'elevated', 'high', 'critical']);
export const OpportunityStatusSchema = z.enum(['candidate', 'ready', 'active', 'measuring', 'archived']);
export const InterventionModeSchema = z.enum([
  'research',
  'writing',
  'code',
  'ops',
  'funding',
  'organizing',
  'mutualAid',
  'education',
]);

export const ScoreDriverSchema = z.object({
  key: z.string(),
  value: z.number().min(-1).max(1),
  note: z.string().optional(),
});

export const ScoreRangeSchema = z
  .object({
    lower: z.number().min(0).max(100),
    upper: z.number().min(0).max(100),
    label: ScoreLabelSchema,
    uncertainty: z.number().min(0).max(1),
    explanation: z.string(),
    drivers: z.array(ScoreDriverSchema).default([]),
  })
  .refine((value) => value.lower <= value.upper, {
    message: 'lower must be <= upper',
    path: ['upper'],
  });

export const EvidenceRefSchema = z.object({
  eventId: z.string(),
  role: z.enum(['supporting', 'disconfirming', 'context']),
  note: z.string(),
  weight: z.number().min(0).max(1),
});

export const AuthorSchema = z.object({
  accountId: z.string(),
  handle: z.string(),
  displayName: z.string().optional(),
  sourceType: SourceTypeSchema,
  verified: z.boolean().default(false),
  labels: z.array(z.string()).default([]),
  followerEstimate: z.number().int().nonnegative().optional(),
});

export const LinkSchema = z.object({
  url: z.string().url(),
  domain: z.string(),
  title: z.string().optional(),
  mimeType: z.string().optional(),
});

export const ProvenanceHopSchema = z.object({
  hop: z.number().int().nonnegative(),
  kind: z.enum(['origin', 'quote', 'repost', 'reply', 'screenshot', 'summary']),
  sourceEventExternalId: z.string().optional(),
  sourceUrl: z.string().url().optional(),
});

export const SignalEventSchema = z.object({
  id: z.string(),
  version: z.literal(1),
  platform: PlatformSchema,
  externalId: z.string(),
  canonicalUrl: z.string().url().optional(),
  occurredAt: z.string().datetime(),
  ingestedAt: z.string().datetime(),
  author: AuthorSchema,
  content: z.object({
    text: z.string(),
    language: z.string().default('en'),
    links: z.array(LinkSchema).default([]),
    mediaUrls: z.array(z.string().url()).default([]),
    parentExternalId: z.string().optional(),
    rootExternalId: z.string().optional(),
    quotedExternalIds: z.array(z.string()).default([]),
  }),
  provenance: z.object({
    firsthandness: FirsthandnessSchema,
    confidenceClass: ConfidenceClassSchema,
    screenshotOnly: z.boolean().default(false),
    chain: z.array(ProvenanceHopSchema).default([]),
    trustCircleIds: z.array(z.string()).default([]),
    labelerFlags: z.array(z.string()).default([]),
  }),
  classification: z.object({
    eventClass: z.array(z.string()).default([]),
    narrativeClass: z.array(z.string()).default([]),
    domainTags: z.array(z.string()).default([]),
    geographyTags: z.array(z.string()).default([]),
    locality: z.enum(['global', 'regional', 'national', 'metro', 'community']).default('global'),
    opportunityTags: z.array(z.string()).default([]),
    communityTags: z.array(z.string()).default([]),
  }),
  engagement: z.object({
    replies: z.number().int().nonnegative().default(0),
    reposts: z.number().int().nonnegative().default(0),
    likes: z.number().int().nonnegative().default(0),
    upvotes: z.number().int().nonnegative().default(0),
    voteVelocity: z.number().min(0).default(0),
  }),
  relationGraph: z.object({
    repostOfEventId: z.string().optional(),
    quoteOfEventIds: z.array(z.string()).default([]),
    replyToEventId: z.string().optional(),
    screenshotOfEventId: z.string().optional(),
    corroboratingUrls: z.array(z.string().url()).default([]),
  }),
  dedupe: z.object({
    lexicalHash: z.string(),
    semanticFingerprint: z.string().optional(),
    urlHash: z.string().optional(),
    mediaHashes: z.array(z.string()).default([]),
  }),
  rawPayload: z.unknown().optional(),
});

export const SourceDistributionSchema = z.object({
  byPlatform: z.record(z.string(), z.number().int().nonnegative()).default({}),
  bySourceType: z.record(z.string(), z.number().int().nonnegative()).default({}),
  byFirsthandness: z.record(z.string(), z.number().int().nonnegative()).default({}),
  byConfidenceClass: z.record(z.string(), z.number().int().nonnegative()).default({}),
});

export const OpportunitySignalsSchema = z.object({
  actionablePosts: z.number().int().nonnegative().default(0),
  resourceLinks: z.number().int().nonnegative().default(0),
  collaboratingCommunities: z.array(z.string()).default([]),
  localActorsMentioned: z.number().int().nonnegative().default(0),
  interventionModes: z.array(InterventionModeSchema).default([]),
});

export const ThreadSchema = z.object({
  id: z.string(),
  version: z.literal(1),
  kind: ThreadKindSchema,
  status: ThreadStatusSchema,
  title: z.string(),
  summary: z.string(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  firstSeenAt: z.string().datetime(),
  lastSeenAt: z.string().datetime(),
  peakAttentionAt: z.string().datetime().optional(),
  subject: z.object({
    canonicalEntityIds: z.array(z.string()).default([]),
    keywords: z.array(z.string()).default([]),
    domainTags: z.array(z.string()).default([]),
    geographyTags: z.array(z.string()).default([]),
    communities: z.array(z.string()).default([]),
    threatTags: z.array(z.string()).default([]),
    opportunityTags: z.array(z.string()).default([]),
    laneHints: z.array(LaneSchema).default([]),
  }),
  membership: z.object({
    eventCount: z.number().int().nonnegative(),
    sampleEventIds: z.array(z.string()).default([]),
  }),
  sourceDistribution: SourceDistributionSchema,
  confidence: z.object({
    corroborationScore: z.number().min(0).max(1),
    evidenceDiversity: z.number().min(0).max(1),
    firsthandRatio: z.number().min(0).max(1),
    officialRatio: z.number().min(0).max(1),
    uncertainty: z.number().min(0).max(1),
  }),
  opportunitySignals: OpportunitySignalsSchema,
  relatedThreadIds: z.array(z.string()).default([]),
});

export const NarrativeBranchSchema = z.object({
  id: z.string(),
  label: z.string(),
  description: z.string(),
  horizon: z.enum(['hours', 'days', 'weeks', 'months']),
  realism: ScoreRangeSchema,
  fearFactor: ScoreRangeSchema,
  publicBenefit: ScoreRangeSchema,
  actionability: ScoreRangeSchema,
  polarizationRisk: ScoreRangeSchema,
  compressionLoss: ScoreRangeSchema,
  watchSignals: z.array(z.string()).default([]),
  supportingEvidence: z.array(EvidenceRefSchema).default([]),
  disconfirmingEvidence: z.array(EvidenceRefSchema).default([]),
});

export const ThreadAssessmentSchema = z.object({
  id: z.string(),
  version: z.literal(1),
  threadId: z.string(),
  reducerVersion: z.string(),
  computedAt: z.string().datetime(),
  window: z.object({
    startAt: z.string().datetime(),
    endAt: z.string().datetime(),
  }),
  laneScores: z.object({
    etaGlobalStress: ScoreRangeSchema,
    localReach: ScoreRangeSchema,
    piBridgeOpportunity: ScoreRangeSchema,
  }),
  sourceHealth: z.object({
    provenanceStrength: ScoreRangeSchema,
    corroboration: ScoreRangeSchema,
    sourceDiversity: ScoreRangeSchema,
    commentaryDominance: ScoreRangeSchema,
    rumorPressure: ScoreRangeSchema,
  }),
  disagreementIndex: ScoreRangeSchema,
  uncertaintyIndex: ScoreRangeSchema,
  polarizationRisk: ScoreRangeSchema,
  compressionLoss: ScoreRangeSchema,
  narrativeBranches: z.array(NarrativeBranchSchema).min(1),
  reasoningSummary: z.array(z.string()).min(1),
  evidenceIndex: z.array(EvidenceRefSchema).default([]),
});

export const FeedbackMetricSchema = z.object({
  key: z.string(),
  description: z.string(),
  targetDirection: z.enum(['up', 'down', 'stable']),
  observationWindowHours: z.number().int().positive(),
});

export const ActionCardSchema = z.object({
  id: z.string(),
  title: z.string(),
  summary: z.string(),
  scope: z.enum(['self', 'network', 'community', 'institution', 'online']),
  effort: z.enum(['tiny', 'small', 'medium', 'large']),
  expectedBenefit: ScoreRangeSchema,
  risk: ScoreRangeSchema,
  reversibility: ScoreRangeSchema,
  interventionMode: InterventionModeSchema,
  feedbackMetric: FeedbackMetricSchema,
  prerequisites: z.array(z.string()).default([]),
  expiresAt: z.string().datetime().optional(),
});

export const ConnectionFitSchema = z.object({
  expertiseMatch: z.number().min(0).max(1),
  projectMatch: z.number().min(0).max(1),
  communityMatch: z.number().min(0).max(1),
  geographyMatch: z.number().min(0).max(1),
  trustCircleMatch: z.number().min(0).max(1),
});

export const ConnectionOpportunitySchema = z.object({
  id: z.string(),
  version: z.literal(1),
  threadId: z.string(),
  assessmentId: z.string(),
  status: OpportunityStatusSchema,
  title: z.string(),
  summary: z.string(),
  globalNeed: z.string(),
  localHypothesis: z.string(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  fit: ConnectionFitSchema,
  opportunityScore: ScoreRangeSchema,
  targetGeographies: z.array(z.string()).default([]),
  targetCommunities: z.array(z.string()).default([]),
  targetModes: z.array(InterventionModeSchema).default([]),
  collaboratingNodes: z.array(z.string()).default([]),
  actionCards: z.array(ActionCardSchema).min(1),
  blockers: z.array(z.string()).default([]),
  risks: z.array(z.string()).default([]),
  feedbackPlan: z.object({
    reviewAfterHours: z.number().int().positive(),
    metrics: z.array(FeedbackMetricSchema).min(1),
    successDefinition: z.string(),
  }),
});

export const PersonalizationSchema = z.object({
  userId: z.string(),
  geography: z.object({
    country: z.string().optional(),
    region: z.string().optional(),
    metro: z.string().optional(),
  }),
  expertiseTags: z.array(z.string()).default([]),
  followedCommunities: z.array(z.string()).default([]),
  savedProjects: z.array(z.string()).default([]),
  preferredInterventionModes: z.array(InterventionModeSchema).default([]),
  federationTrustCircles: z.array(z.string()).default([]),
  sourceWeights: z.record(z.string(), z.number().min(0).max(3)).default({}),
  agencyBias: z.number().min(0).max(1).default(0.7),
  uncertaintyTolerance: z.number().min(0).max(1).default(0.5),
  compressionResistance: z.number().min(0).max(1).default(0.8),
  alertIntensity: z.number().min(0).max(1).default(0.5),
});

export type Platform = z.infer<typeof PlatformSchema>;
export type SourceType = z.infer<typeof SourceTypeSchema>;
export type ConfidenceClass = z.infer<typeof ConfidenceClassSchema>;
export type Firsthandness = z.infer<typeof FirsthandnessSchema>;
export type ThreadKind = z.infer<typeof ThreadKindSchema>;
export type ThreadStatus = z.infer<typeof ThreadStatusSchema>;
export type Lane = z.infer<typeof LaneSchema>;
export type ScoreRange = z.infer<typeof ScoreRangeSchema>;
export type SignalEvent = z.infer<typeof SignalEventSchema>;
export type Thread = z.infer<typeof ThreadSchema>;
export type NarrativeBranch = z.infer<typeof NarrativeBranchSchema>;
export type ThreadAssessment = z.infer<typeof ThreadAssessmentSchema>;
export type ActionCard = z.infer<typeof ActionCardSchema>;
export type ConnectionOpportunity = z.infer<typeof ConnectionOpportunitySchema>;
export type Personalization = z.infer<typeof PersonalizationSchema>;

export interface GaugeDefinition {
  id: string;
  label: string;
  description: string;
  sourceKeys: string[];
  thresholds: Array<{ label: z.infer<typeof ScoreLabelSchema>; min: number }>;
}

export interface ThreadFeatureVector {
  noveltyVelocity: number;
  provenanceStrength: number;
  corroboration: number;
  sourceDiversity: number;
  uncertainty: number;
  geoProximity: number;
  domainMatch: number;
  networkMatch: number;
  actionability: number;
  publicBenefit: number;
  fearFactor: number;
  polarizationRisk: number;
  compressionLoss: number;
  collaboratorAvailability: number;
}
