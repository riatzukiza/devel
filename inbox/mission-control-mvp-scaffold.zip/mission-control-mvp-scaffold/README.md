# Mission Control MVP scaffold

This scaffold turns your mockup into four stable backend objects plus one snapshot composer that feeds the UI you described.

Files:

- `src/domain/types.ts` - runtime-safe schemas and TypeScript types for the core objects
- `src/domain/reducer.ts` - deterministic scoring, branch drafting, and Pi opportunity generation
- `src/ui/panelMapping.ts` - mapping from reducer outputs to the hero panel, stress clock, lanes, action feed, and critical rails

## 1. Core object decisions

### SignalEvent

Use `SignalEvent` as the intake contract for every platform. It carries:

- canonical platform identity (`platform`, `externalId`, `canonicalUrl`)
- author metadata and source class
- provenance (`firsthand`, `commentary`, `rumor`, `synthesis`, `official`)
- classification tags (`eventClass`, `narrativeClass`, `domainTags`, `geographyTags`, `communityTags`)
- relation graph for reposts, quotes, screenshots, and corroborating links
- dedupe fingerprints so one screenshot or quote chain does not explode your counts

This lets Bluesky and Reddit shape attention without deciding truth.

### Thread

Keep `Thread` as a stable merged topic object, not a presentation object. It should be cheap to recompute and version. The scaffold separates:

- thread kind: `event | narrative | opportunity`
- source distribution
- confidence envelope
- opportunity signals
- lane hints and related threads

One event can belong to multiple threads via a join table in storage.

### ThreadAssessment

This is the reducer output, versioned by reducer build. It contains:

- three lane scores: `etaGlobalStress`, `localReach`, `piBridgeOpportunity`
- source health metrics
- disagreement, uncertainty, polarization risk, compression loss
- narrative branches with supporting and disconfirming evidence refs
- reasoning summary for explainability chips and hover states

The important part is that every score is a range, not fake precision.

### ConnectionOpportunity

This is the Pi object. It links one thread to one local bridge hypothesis. It carries:

- fit against expertise, project, community, geography, and trust circles
- an opportunity score
- action cards
- blockers and risks
- a feedback plan with concrete metrics and a review window

That keeps Pi aligned with coordination and feedback, not slogans.

## 2. Suggested storage layout

The TypeScript schemas are the source of truth for contracts. In Postgres, model them roughly like this:

- `signal_events`
  - `id`
  - `platform`
  - `external_id`
  - `occurred_at`
  - `ingested_at`
  - `author_json`
  - `content_json`
  - `provenance_json`
  - `classification_json`
  - `relation_graph_json`
  - `dedupe_json`
  - `raw_payload_json`
  - unique key on `(platform, external_id)`
  - secondary indexes on `occurred_at`, `platform`, and your vector store key

- `threads`
  - `id`
  - `kind`
  - `status`
  - `title`
  - `summary`
  - `subject_json`
  - `membership_json`
  - `source_distribution_json`
  - `confidence_json`
  - `opportunity_signals_json`
  - `related_thread_ids`

- `thread_membership`
  - `thread_id`
  - `signal_event_id`
  - `membership_role`
  - `membership_weight`
  - composite unique key on `(thread_id, signal_event_id)`

- `thread_assessments`
  - `id`
  - `thread_id`
  - `reducer_version`
  - `computed_at`
  - `assessment_json`
  - index on `(thread_id, reducer_version, computed_at desc)`

- `connection_opportunities`
  - `id`
  - `thread_id`
  - `assessment_id`
  - `status`
  - `opportunity_json`
  - index on `status`, `thread_id`

For the MVP, JSONB is fine. Normalize later only if query cost becomes painful.

## 3. Reducer contract

The reducer uses only deterministic features and user-configurable weights.

Feature families in `src/domain/reducer.ts`:

- freshness and attention: `noveltyVelocity`
- source quality: `provenanceStrength`, `corroboration`, `sourceDiversity`
- uncertainty: explicit uncertainty widened by rumor share
- relevance: `geoProximity`, `domainMatch`, `networkMatch`
- usefulness: `actionability`, `publicBenefit`, `collaboratorAvailability`
- anti-flattening: `polarizationRisk`, `compressionLoss`

The actual lane formulas in the scaffold are:

- `etaGlobalStress`
  - threat intensity
  - novelty velocity
  - provenance strength
  - corroboration

- `localReach`
  - geography overlap
  - domain overlap
  - network overlap
  - actionability

- `piBridgeOpportunity`
  - actionability
  - domain overlap
  - network overlap
  - collaborator availability
  - public benefit

These formulas are deliberately legible. You can argue about weights and compare reducer versions later.

## 4. UI wiring

`src/ui/panelMapping.ts` composes one `DashboardSnapshot` that your React mockup can consume directly.

It maps backend data to your panels like this:

- hero mission panel
  - `agency` <- mean Pi opportunity score and reversibility posture
  - `nuance` <- source diversity + disagreement - compression loss
  - `critical` <- provenance + corroboration - rumor pressure

- composite stress clock
  - mean of active `etaGlobalStress` values
  - uncertainty glow from assessment uncertainty
  - sweep period and amplitude only; client owns live animation

- firehose intake
  - most recent `SignalEvent`s with provenance chips and confidence class

- `eta Global`
  - top assessments sorted by `etaGlobalStress`

- `Local Reach`
  - top assessments sorted by `localReach`

- `Pi Connections`
  - top `ConnectionOpportunity`s sorted by opportunity score

- action feed
  - flattened action cards, sorted by expected benefit and then low effort

- critical-thinking rails
  - threads with the highest polarization risk + compression loss
  - each rail shows branch cards instead of a single collapsed headline

## 5. Runtime shape for the frontend

A useful backend contract is:

- `GET /api/v1/dashboard/snapshot`
  - returns one `DashboardSnapshot`

- `GET /api/v1/threads/:threadId`
  - thread detail plus latest assessment and related opportunities

- `GET /api/v1/firehose?limit=50`
  - recent normalized `SignalEvent`s

- `WS /api/v1/live`
  - push lightweight invalidation messages or partial panel updates

For the MVP, do not stream every raw event into React. Stream snapshots or patch sets every 5 to 15 seconds.

## 6. Worker split

Use four small worker families instead of one giant service:

1. intake workers
   - Bluesky collector
   - Reddit collector
   - normalize to `SignalEvent`

2. identity and threading workers
   - dedupe
   - quote chain resolution
   - thread membership updates

3. reducer workers
   - compute `ThreadAssessment`
   - generate `ConnectionOpportunity`

4. snapshot composer
   - build per-user `DashboardSnapshot`
   - cache latest snapshot in Redis

That fits your "pipeline, not monolith" instinct.

## 7. Where to put user controls

The `Personalization` schema already contains the controls you described:

- `sourceWeights`
- `agencyBias`
- `uncertaintyTolerance`
- `compressionResistance`
- `alertIntensity`
- `federationTrustCircles`
- expertise, communities, saved projects, intervention modes, geography

Keep these in Postgres as user config, but mirror the active snapshot in Redis for reducer jobs.

## 8. MVP lane recommendation

Your suggested MVP is right. I would freeze the first release around:

- eta family: geopolitical + infrastructure stress
- local family: open-source AI and dev community relevance
- Pi bridge: global energy or conflict stress -> local AI infra response

Three reasons:

- enough heterogeneity to test the model
- enough local action surface to make agency real
- still small enough to debug the reducer without drowning in topic sprawl

## 9. Integration sequence

1. land `SignalEvent` normalization for Bluesky + Reddit
2. write the `Thread` builder and membership table
3. run the reducer on a fixed replay set and tune weights
4. emit `ThreadAssessment` and `ConnectionOpportunity`
5. build `DashboardSnapshot`
6. point the React mockup at the snapshot endpoint
7. add streaming patch updates only after snapshot rendering feels stable

## 10. What I would do next

The next concrete step is to add one thin service boundary:

- reducer input: `Thread[] + Personalization`
- reducer output: `ThreadAssessment[] + ConnectionOpportunity[]`
- snapshot output: `DashboardSnapshot`

That boundary will let you replay old intake windows, compare reducer versions, and test whether the UI still resists political flattening once real noisy data is flowing.
