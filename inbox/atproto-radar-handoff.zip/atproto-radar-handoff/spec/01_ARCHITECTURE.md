# ATProto-First Architecture for Mission Control / News Radar

## Why this shape

Free cloud SQL changes the optimization target.

The right move is to treat SQL as a **thin coordination membrane**, not the source of truth for everything.
ATProto already gives you:
- durable account identity
- signed records
- public/federated distribution
- a relay/firehose model
- schema via Lexicons

So the architecture should exploit that.

## System topology

```mermaid
flowchart LR
  Browser["Browser App\nOAuth + IndexedDB + WebNN/WebGPU"]
  PDS["User PDS / Service PDS"]
  Relay["Relay / Firehose"]
  App["Tiny App Backend"]
  Obj["Blob/Object Store"]
  SQL["Tiny SQL"]
  Queue["Ephemeral Queue/Memory Cache"]

  Browser -->|OAuth + record publish/query| PDS
  PDS -->|repo events| Relay
  Relay -->|subscribeRepos| App
  Browser -->|submit signed local packet| App
  App --> SQL
  App --> Queue
  App --> Obj
  App -->|optional service records| PDS
```

## Primary design rules

1. **DID over handle**
   - everything internally keys off DID
   - handles are display and discovery only

2. **Repo records over SQL rows**
   - if data is public/federated and durable, prefer a record
   - only mirror locally when query speed or moderation requires it

3. **Browser cache over server cache**
   - large user-local state belongs in IndexedDB first
   - avoid round-tripping personalized views into SQL

4. **Service repos over app tables**
   - for global/shared instruments, use service accounts and repos
   - use SQL to track only operational metadata

5. **Signed packets over mutable dashboard rows**
   - append packets, reduce deterministically, publish snapshots
   - do not rewrite history unless publishing a superseding record

## Storage policy

### Put in ATProto
- public source bundles
- packet submissions
- assessment snapshots
- branch maps
- action cards
- render profiles intended for sharing
- trust circle declarations intended to be public/federated
- source weighting presets that are meant to travel between nodes

### Put in browser IndexedDB
- private local drafts
- ephemeral embedding caches
- recently viewed thread graphs
- model files / tokenizer assets
- device benchmark outputs
- local reducer experiments
- unpublished user prefs

### Put in object storage
- big binary artifacts
- charts / generated images / report exports
- archived firehose slices if you choose to retain them

### Put in tiny SQL
- OAuth session row
- refresh-token/session references
- relay cursor checkpoints
- outbox retries
- rate limit counters
- abuse signals
- optional compact materialized cache of latest snapshots

## Data flow

### 1. Identity
Browser starts ATProto OAuth.
Backend helps with callback completion and optional session persistence.
Principal = DID.

### 2. Packet creation
Browser or service emits signed packet conforming to Lexicon.

### 3. Publication
Packet is published to:
- user repo, or
- shared service repo, or
- backend endpoint which republishes after validation

### 4. Discovery
App backend consumes firehose / relay and filters Lexicon collections of interest.

### 5. Reduction
Reducer runs deterministically over packet sets.
Output can be:
- local-only preview
- shared assessment record
- cached JSON snapshot for wall UI

### 6. Action feedback
Users publish action cards / experiment feedback records.
Reducers can ingest them later.

## Recommended role split

### Browser
- auth start
- local cache
- local compute
- publishing signed packets
- rendering dashboard

### Backend
- verify signatures
- keep cursors
- subscribe to relays
- republish service records
- rate limiting and abuse controls

### SQL
- operational crumbs only
