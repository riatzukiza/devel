# Agent Brief

You are implementing an **ATProto-first, SQL-minimal** system.

## Non-negotiables

1. DID is the primary identity key.
2. SQL is not the source of truth for packets/assessments.
3. Lexicon records define the public data plane.
4. Browser app should be able to function in a mostly local-first mode.
5. Firehose/relay ingestion must be resumable via cursor checkpointing.
6. Reducer semantics remain deterministic and versioned.

## First tasks

1. Publish client metadata for browser OAuth.
2. Finalize Lexicons in `lexicons/`.
3. Implement browser auth module with real PAR/PKCE/DPoP.
4. Implement real record publication/query using an atproto SDK.
5. Implement relay subscriber with persistent cursor checkpoint.
6. Use only the minimal SQL schema in `sql/minimal_schema.sql`.
7. Add IndexedDB caches for packets, assessments, and model assets.
8. Wire branch/action packet publication from browser.

## Acceptance criteria

- user can sign in with ATProto OAuth
- principal is stored as DID
- browser can create and locally cache packet drafts
- packet can be published as a Lexicon record
- backend can consume relay events and checkpoint cursor
- reducer can generate a shared assessment without storing the full corpus in SQL
- SQL remains under tight footprint limits
