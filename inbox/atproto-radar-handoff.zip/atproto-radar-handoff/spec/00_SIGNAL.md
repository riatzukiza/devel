# Signal

The architecture is now **repo-first, SQL-last**.

The system uses ATProto for:
- user identity (DID)
- OAuth login / authorization
- public and federated records
- discovery via relay / firehose
- trust overlays via labels

The system uses local SQL only for:
- session state
- cursors/checkpoints
- retry jobs
- rate limits / quotas
- a tiny hot cache if absolutely necessary

The browser should become a serious node:
- IndexedDB for local cache and work products
- WebNN/WebGPU/WASM for local compute
- direct signed packet publication where appropriate
- background sync via service worker when possible

## New boundary

### Public / federated plane
ATProto records:
- radar packet
- reduced assessment
- branch map
- action card
- trust declaration
- source bundle declaration

### Private control plane
Own backend:
- OAuth callback completion
- optional encrypted refresh-token/session storage
- relay cursors
- packet dedupe
- moderation / abuse throttles
- optional outbox retry and webhook fanout

### Local-first browser plane
Browser:
- user prefs
- most read models
- hot packet cache
- local embeddings / branch drafts
- local reducer previews
