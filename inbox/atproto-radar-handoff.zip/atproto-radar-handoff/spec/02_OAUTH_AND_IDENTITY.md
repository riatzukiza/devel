# OAuth and Identity Plan

## Identity model

Primary key:
- `did`

Secondary identity:
- handle
- display name
- service endpoint metadata

Never use handle as foreign key.

## Browser OAuth model

The browser app is a **public OAuth client**.

### Required implementation posture
- client metadata hosted at HTTPS URL
- authorization code flow
- PKCE
- PAR
- DPoP
- non-exportable browser key material where possible
- IndexedDB persistence for session material

## Minimal requested permissions

Start with:
- `atproto`

Then add only what is necessary for publishing / querying your own collections.

Avoid broad transitional scopes unless absolutely necessary.

## Session strategy

### Browser-only mode
Best for ultra-cheap deployment.
- keep tokens in browser storage
- backend stores no refresh token
- backend only verifies signed packets and consumes relays

### Hybrid mode
Best for shared dashboards / wall displays.
- browser holds active auth session
- backend stores minimal encrypted session reference for background publishing or sync

## DID-first local model

```ts
type Principal = {
  did: string;
  handle?: string;
  pdsUrl?: string;
  lastAuthAt: string;
  scopes: string[];
}
```

## Security notes

- verify that the returned `sub` DID matches the originally resolved DID
- rotate DPoP/session material per auth session
- do not rely on handle continuity
- keep backend service auth separate from user OAuth

## Cost notes

If you are extremely SQL-constrained:
- do not store full user profiles in SQL
- store only:
  - did
  - session reference / encrypted token ref
  - created_at / updated_at
  - last_seen_at
  - small JSON scope list
