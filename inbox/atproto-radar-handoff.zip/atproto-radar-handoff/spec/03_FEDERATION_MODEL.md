# Federation Model

## Principle

Federation is not "our app database replicated everywhere."

Federation is:
- signed records
- schema agreement
- replayable public history
- selective local mirroring
- trust overlays

## ATProto primitives to use

- repo records for packets/snapshots
- relays/firehose for discovery
- labels/labelers for trust/provenance
- service accounts for shared radars
- AppView-style services for aggregated views if needed later

## Record strategy

### User repo records
Use when authorship matters:
- observations
- local packet submissions
- local action reports
- trust declarations

### Service repo records
Use when shared instrument state matters:
- canonical radar definitions
- merged assessments
- curated source bundles
- published render profiles
- federated branch consensus summaries

## Recommended collections

- `com.promethean.radar.definition`
- `com.promethean.radar.packet`
- `com.promethean.radar.assessment`
- `com.promethean.radar.branchMap`
- `com.promethean.radar.actionCard`
- `com.promethean.radar.sourceBundle`
- `com.promethean.radar.renderProfile`
- `com.promethean.radar.trustDeclaration`

## Label overlays

Use signed labels for:
- firsthand
- commentary
- rumor
- synthesis
- trusted-source
- weak-corroboration
- high-compression-loss
- high-polarization-risk

## Mirroring policy

Mirror only what you need for:
- dashboard speed
- abuse defense
- deterministic reduction windows
- search / analytics

Everything else can be rehydrated from repo data or replayed from the relay stream.

## Cheap deployment profile

### Zero-heavy-DB mode
- 1 free SQL database
- 1 tiny backend
- 1 object store bucket
- 1 browser app
- 1 relay subscriber worker

SQL stores:
- cursors
- sessions
- outbox
- quotas

Everything else:
- repo records
- browser cache
- object store
