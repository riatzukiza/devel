# SQL Minimization Guide

## The rule

If a thing is:
- public
- durable
- append-oriented
- useful across nodes

...it probably belongs in ATProto or object storage, not SQL.

If a thing is:
- secret
- short-lived
- retry-oriented
- checkpoint-oriented
- rate-limiting-related

...it belongs in tiny SQL.

## Tables you are allowed to have

1. `auth_session`
2. `relay_cursor`
3. `outbox_retry`
4. `rate_limit_bucket`
5. `hot_snapshot_cache` (optional)
6. `abuse_event` (optional)

That is enough for an MVP.

## Tables to avoid

Avoid building:
- giant `users`
- giant `threads`
- giant `posts`
- giant `sources`
- giant `packets`
- giant `assessments`

Those are the trap. They turn your free-tier SQL into the product's bottleneck.

## Materialization policy

If you really need SQL search/speed:
- materialize only the latest snapshot per radar
- keep only rolling recent windows
- aggressively TTL anything reproducible

## TTL defaults

- relay cursor: permanent
- auth session: 30 days
- outbox retry: 7 days
- rate limit bucket: 1 day rolling
- hot snapshot cache: 1-24 hours
- abuse event: 30-90 days

## Compression tactics

- store hashes / CIDs instead of full payloads
- store compact JSON, not repeated relational joins
- avoid duplicate denormalized user metadata
- use browser IndexedDB for personalized views
