# ATProto-First Mission Control / News Radar Handoff

This package reorients the earlier scaffold around an **ATProto-first** architecture
to minimize SQL usage on free cloud databases.

## Core posture

- **ATProto DID** is the primary user identifier.
- **ATProto OAuth** is the user authn/authz entry point.
- **ATProto Lexicon records** are the durable public/federated data plane.
- **Firehose / relay consumption** is the discovery + sync plane.
- **Labels / labelers** are the trust/provenance overlay.
- **Local SQL** is intentionally tiny:
  - auth session bookkeeping
  - relay cursor checkpoints
  - retry/outbox jobs
  - usage accounting / rate limits
  - optional tiny materialized hot cache

Everything else should live in:
- user repos / service repos on ATProto
- browser IndexedDB / local cache
- signed blobs / object storage if needed
- ephemeral queues / in-memory caches

## Package layout

- `spec/`
  - architecture, OAuth, storage minimization, federation plan, agent brief
- `lexicons/`
  - proposed custom Lexicons for radar packets, assessments, branch maps, action cards
- `client/`
  - browser auth skeleton, IndexedDB cache, WebNN/WebGPU compute hooks, federation publisher stubs
- `server/`
  - tiny Express app, signature verification, firehose subscriber skeleton, record mirror/publisher stubs
- `sql/`
  - minimal schema only
- `notes/`
  - migration notes and design commentary

## Intended handoff

Give this entire folder to a local coding agent and tell it:

1. implement real ATProto browser OAuth against published client metadata
2. finalize Lexicons and publish them in a schema repo
3. wire record publishing / querying with a real atproto client SDK
4. keep SQL constrained to the provided minimal schema
5. add test coverage for canonical signing, record serialization, and cursor recovery

## What is intentionally stubbed

- full OAuth PAR/DPoP request choreography
- real firehose decoding
- actual record publishing via SDK
- tokenizer/model asset management for browser inference

The stubs are in place so the agent can replace them directly.
