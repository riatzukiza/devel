# Migration Plan

## Step 1
Stop modeling packets and assessments as first-class SQL entities.

## Step 2
Introduce Lexicon records and service repos.

## Step 3
Move browser state into IndexedDB:
- session cache
- packet drafts
- local snapshots
- model assets

## Step 4
Keep only minimal SQL:
- auth_session
- relay_cursor
- outbox_retry
- rate_limit_bucket
- hot_snapshot_cache

## Step 5
Add relay/firehose consumer.

## Step 6
Reduce deterministically over mirrored packet windows, not giant SQL joins.

## Step 7
Optionally publish merged assessments back to a service repo.

## Step 8
Only materialize extra SQL indexes if a specific query proves impossible otherwise.
