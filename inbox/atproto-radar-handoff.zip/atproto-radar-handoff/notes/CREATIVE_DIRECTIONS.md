# Creative Directions

## Wild but coherent directions

### 1. Browser as sovereign node
Turn the browser into the first-class execution environment:
- ATProto auth
- local embeddings
- local reducer
- signed packet publish
- local-first UI
- "federation ready" without central backend

### 2. Service repo as instrument panel
Instead of storing dashboards in SQL:
- store radar definitions in service repo
- store reduced daily snapshots in service repo
- wall site reads active radars from repo records plus small JSON cache

### 3. Labels as cognitive instrumentation
Use labels to annotate not morality but epistemics:
- low corroboration
- firsthand
- synthetic summary
- compression-loss hazard
- polarization trigger
- local-action potential

### 4. SQL as scar tissue only
Treat SQL as:
- a checkpoint notebook
- not the body

### 5. Multi-home renderers
Any node that understands the Lexicons can render:
- clock wall
- branch maps
- action feed
- source bundle inspector
