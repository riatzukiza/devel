create table if not exists auth_session (
  did text primary key,
  handle text,
  session_ref text,
  scopes jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists relay_cursor (
  relay_url text primary key,
  cursor text not null,
  updated_at timestamptz not null default now()
);

create table if not exists outbox_retry (
  id bigserial primary key,
  job_type text not null,
  payload jsonb not null,
  attempts integer not null default 0,
  next_attempt_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists rate_limit_bucket (
  bucket_key text primary key,
  tokens integer not null,
  reset_at timestamptz not null
);

create table if not exists hot_snapshot_cache (
  cache_key text primary key,
  snapshot jsonb not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create index if not exists outbox_retry_due_idx on outbox_retry (next_attempt_at);
create index if not exists hot_snapshot_cache_expires_idx on hot_snapshot_cache (expires_at);
