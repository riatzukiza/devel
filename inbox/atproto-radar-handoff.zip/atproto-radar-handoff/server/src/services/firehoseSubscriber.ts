/**
 * Firehose subscriber scaffold.
 *
 * Replace the fake loop with a real com.atproto.sync.subscribeRepos consumer.
 * Persist only the relay cursor and maybe a tiny hot cache. Do not dump the entire
 * public corpus into SQL.
 */
import type { Pool } from "pg";
import { getRelayCursor, upsertRelayCursor } from "../storage/minimalDb.js";

export async function runFirehoseSubscriber(pool: Pool, relayUrl: string) {
  const lastCursor = await getRelayCursor(pool, relayUrl);
  console.log("[firehose] starting with cursor", lastCursor);

  // TODO: connect to relay websocket, pass cursor, decode frames, filter collections of interest
  // For now this is a placeholder.
  let cursor = lastCursor ? Number(lastCursor) : 0;
  setInterval(async () => {
    cursor += 1;
    await upsertRelayCursor(pool, relayUrl, String(cursor));
    console.log("[firehose] checkpoint", cursor);
  }, 15000);
}
