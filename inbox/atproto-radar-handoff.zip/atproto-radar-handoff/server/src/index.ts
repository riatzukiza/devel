import express from "express";
import bodyParser from "body-parser";
import { createPool } from "./storage/minimalDb.js";
import { registerHealthRoute } from "./routes/health.js";
import { registerVerifyPacketRoute } from "./routes/verifyPacket.js";
import { registerSubmitPacketRoute } from "./routes/submitPacket.js";
import { runFirehoseSubscriber } from "./services/firehoseSubscriber.js";

const app = express();
app.use(bodyParser.json({ limit: "1mb" }));

registerHealthRoute(app);
registerVerifyPacketRoute(app);
registerSubmitPacketRoute(app);

const port = Number(process.env.PORT || 8787);
const relayUrl = process.env.ATPROTO_RELAY_URL || "wss://example.invalid/subscribeRepos";

async function main() {
  const pool = createPool();
  void runFirehoseSubscriber(pool, relayUrl);
  app.listen(port, () => {
    console.log(`[server] listening on :${port}`);
  });
}

main().catch((error) => {
  console.error("[server] fatal", error);
  process.exit(1);
});
