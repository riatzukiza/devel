import { Pool } from "pg";

export function createPool() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("DATABASE_URL is required");
  }
  return new Pool({ connectionString });
}

export async function upsertRelayCursor(pool: Pool, relayUrl: string, cursor: string) {
  await pool.query(
    `
    insert into relay_cursor (relay_url, cursor, updated_at)
    values ($1, $2, now())
    on conflict (relay_url)
    do update set cursor = excluded.cursor, updated_at = now()
    `,
    [relayUrl, cursor],
  );
}

export async function getRelayCursor(pool: Pool, relayUrl: string): Promise<string | null> {
  const result = await pool.query(`select cursor from relay_cursor where relay_url = $1`, [relayUrl]);
  return result.rows[0]?.cursor ?? null;
}
