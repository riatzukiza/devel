import type { Express } from "express";
import { verifySignedPayload } from "../lib/verify.js";

export function registerVerifyPacketRoute(app: Express) {
  app.post("/v1/packets/verify", (req, res) => {
    try {
      const { payload, publicJwk, signature } = req.body ?? {};
      const valid = verifySignedPayload(payload, publicJwk, signature);
      res.json({ ok: true, valid });
    } catch (error) {
      res.status(400).json({ ok: false, error: String(error) });
    }
  });
}
