import type { Express } from "express";
import { verifySignedPayload } from "../lib/verify.js";
import { publishPacketRecord } from "../services/packetPublisher.js";

function isReasonablePacket(value: any): boolean {
  return (
    value &&
    typeof value === "object" &&
    typeof value.radarId === "string" &&
    typeof value.createdAt === "string" &&
    typeof value.authorDid === "string" &&
    Array.isArray(value.signals)
  );
}

export function registerSubmitPacketRoute(app: Express) {
  app.post("/v1/packets/submit", async (req, res) => {
    try {
      const { payload, publicJwk, signature } = req.body ?? {};
      if (!isReasonablePacket(payload)) {
        return res.status(400).json({ ok: false, error: "invalid_packet_shape" });
      }
      const valid = verifySignedPayload(payload, publicJwk, signature);
      if (!valid) {
        return res.status(400).json({ ok: false, error: "invalid_signature" });
      }

      // TODO: enforce abuse limits, evidenceRef checks, DID/session checks if needed.
      const publishResult = await publishPacketRecord(payload);
      return res.json({
        ok: true,
        accepted: true,
        publishResult,
      });
    } catch (error) {
      return res.status(400).json({ ok: false, error: String(error) });
    }
  });
}
