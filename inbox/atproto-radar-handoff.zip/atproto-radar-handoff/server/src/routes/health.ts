import type { Express } from "express";

export function registerHealthRoute(app: Express) {
  app.get("/healthz", (_req, res) => {
    res.json({ ok: true, service: "promethean-radar-server" });
  });
}
