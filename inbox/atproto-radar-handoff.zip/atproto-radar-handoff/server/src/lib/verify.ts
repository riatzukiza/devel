import crypto from "crypto";
import jwkToPem from "jwk-to-pem";
import { stableStringify } from "./canonical.js";

export function verifySignedPayload(payload: unknown, publicJwk: JsonWebKey, signatureBase64: string): boolean {
  const canonical = stableStringify(payload);
  const pem = jwkToPem(publicJwk as any);
  const verifier = crypto.createVerify("SHA256");
  verifier.update(canonical);
  verifier.end();
  const signature = Buffer.from(signatureBase64, "base64");
  return verifier.verify(pem, signature);
}
