import * as ort from "onnxruntime-web";

export async function detectAccelerators() {
  const hasWebGPU = !!(navigator as any).gpu;
  const hasWebNN = (navigator as any).ml !== undefined;
  return { hasWebGPU, hasWebNN };
}

export async function createOrtSession(modelUrl: string) {
  const { hasWebGPU, hasWebNN } = await detectAccelerators();
  const providers = hasWebNN ? ["webnn", "webgpu", "wasm"] : hasWebGPU ? ["webgpu", "wasm"] : ["wasm"];
  return await ort.InferenceSession.create(modelUrl, {
    executionProviders: providers,
    graphOptimizationLevel: "all",
  } as any);
}

export function truncateAndNormalize(vector: Float32Array, dim: number): Float32Array {
  const out = vector.slice(0, dim);
  let norm = 0;
  for (const item of out) norm += item * item;
  norm = Math.sqrt(norm) || 1;
  for (let i = 0; i < out.length; i += 1) out[i] /= norm;
  return out;
}
