/**
 * Browser OAuth scaffold for ATProto.
 *
 * This is intentionally incomplete:
 * - client metadata hosting is external to this file
 * - PAR/DPoP request choreography is stubbed but typed
 * - DID/PDS verification must be completed by the implementing agent
 */

export type BeginAuthInput = {
  identifier: string; // handle or DID
  clientId: string;   // metadata URL
  redirectUri: string;
  scopes: string[];
};

export type BeginAuthOutput = {
  state: string;
  verifier: string;
  challenge: string;
  authorizeUrl: string;
};

export async function createPkcePair(): Promise<{ verifier: string; challenge: string }> {
  const verifier = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  const challenge = btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");
  return { verifier, challenge };
}

export async function beginAtprotoAuth(input: BeginAuthInput): Promise<BeginAuthOutput> {
  const state = crypto.randomUUID();
  const { verifier, challenge } = await createPkcePair();

  // TODO:
  // 1. resolve identifier -> DID -> auth server / PDS
  // 2. create DPoP keypair and keep non-exportable private key in IndexedDB
  // 3. send PAR request
  // 4. build authorize URL from returned request_uri
  const authorizeUrl = `/TODO/authorize?identifier=${encodeURIComponent(input.identifier)}&client_id=${encodeURIComponent(input.clientId)}&redirect_uri=${encodeURIComponent(input.redirectUri)}&scope=${encodeURIComponent(input.scopes.join(" "))}&state=${encodeURIComponent(state)}&code_challenge=${encodeURIComponent(challenge)}`;

  return { state, verifier, challenge, authorizeUrl };
}
