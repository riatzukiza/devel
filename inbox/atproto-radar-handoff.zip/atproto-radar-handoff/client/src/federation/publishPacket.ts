import { signCanonicalPayload } from "../auth/canonical";
import type { RadarPacket } from "../types/records";

export type PublishSignedPacketInput = {
  packet: RadarPacket;
  publicJwk: JsonWebKey;
  privateKey: CryptoKey;
  submitUrl: string;
};

export async function publishSignedPacket(input: PublishSignedPacketInput) {
  const signature = await signCanonicalPayload(input.privateKey, input.packet);
  const response = await fetch(input.submitUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      payload: input.packet,
      publicJwk: input.publicJwk,
      signature,
    }),
  });
  if (!response.ok) {
    throw new Error(`publish failed: ${response.status}`);
  }
  return await response.json();
}
