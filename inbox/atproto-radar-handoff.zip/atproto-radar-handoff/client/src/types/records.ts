export type RadarLaneInterval = {
  low: number;
  mid: number;
  high: number;
};

export type RadarPacket = {
  radarId: string;
  createdAt: string;
  authorDid: string;
  title?: string;
  summary?: string;
  signals: Array<{
    key: string;
    score: number;
    confidence?: number;
    note?: string;
  }>;
  branchHints?: string[];
  evidenceRefs?: string[];
};

export type RadarAssessment = {
  radarId: string;
  createdAt: string;
  reducerVersion: string;
  lanes: {
    eta: RadarLaneInterval;
    mu: RadarLaneInterval;
    pi: RadarLaneInterval;
  };
  disagreement?: number;
  compressionLoss?: number;
  polarizationRisk?: number;
  packetRefs?: string[];
};

export type AuthSessionState = {
  did: string;
  handle?: string;
  pdsUrl?: string;
  scopes: string[];
  accessToken?: string;
  refreshToken?: string;
  dpopPublicJwk?: JsonWebKey;
};
