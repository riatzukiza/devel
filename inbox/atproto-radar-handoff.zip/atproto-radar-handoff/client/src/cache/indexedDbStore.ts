/**
 * Minimal IndexedDB wrapper.
 * Keep browser-heavy state here instead of SQL.
 */
const DB_NAME = "promethean-radar";
const DB_VERSION = 1;
const STORE_SESSIONS = "sessions";
const STORE_PACKETS = "packetDrafts";
const STORE_SNAPSHOTS = "snapshotCache";
const STORE_MODELS = "modelCache";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_SESSIONS)) db.createObjectStore(STORE_SESSIONS, { keyPath: "did" });
      if (!db.objectStoreNames.contains(STORE_PACKETS)) db.createObjectStore(STORE_PACKETS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(STORE_SNAPSHOTS)) db.createObjectStore(STORE_SNAPSHOTS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(STORE_MODELS)) db.createObjectStore(STORE_MODELS, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function putObject<T>(storeName: string, value: T): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).put(value as any);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getObject<T>(storeName: string, key: IDBValidKey): Promise<T | undefined> {
  const db = await openDb();
  return await new Promise<T | undefined>((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => resolve(req.result as T | undefined);
    req.onerror = () => reject(req.error);
  });
}

export const stores = {
  sessions: STORE_SESSIONS,
  packetDrafts: STORE_PACKETS,
  snapshotCache: STORE_SNAPSHOTS,
  modelCache: STORE_MODELS,
};
