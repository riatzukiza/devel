from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent.parent
zip_path = root.parent / "atproto-radar-handoff.zip"

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for path in root.rglob("*"):
        if path.is_file():
            zf.write(path, path.relative_to(root.parent))

print(zip_path)
