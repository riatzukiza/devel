/**
 * Ollama LLM Provider for Cephalon
 *
 * Integrates with local Ollama instance for qwen3-vl:2b-instruct
 * Uses the official ollama npm module
 */

import { Ollama } from "ollama";
import { InMemoryEventBus, type EventBus } from "@promethean-os/event";
import type {
  Session,
  CephalonEvent,
  CephalonPolicy,
  ToolCall,
  ToolResult,
  ChatMessage,
} from "../types/index.js";
import {
  assembleContext,
  createHeuristicTokenizer,
  generatePersonaHeader,
  getCurrentPersonaName,
} from "../context/assembler.js";
import { InMemoryMemoryStore, type MemoryStore } from "../core/memory-store.js";
import {
  mintFromDiscordEvent,
  mintFromLLMResponse,
  mintFromToolCall,
} from "../core/minting.js";
import { DiscordApiClient } from "../discord/api-client.js";
import { getAllToolDefinitions, type ToolDefinition } from "../prompts/index.js";

export interface OllamaConfig {
  baseUrl: string;
  model: string;
  temperature?: number;
  maxTokens?: number;
}

export interface LLMProvider {
  complete(messages: ChatMessage[]): Promise<string>;
  completeWithTools(
    messages: ChatMessage[],
    tools: ToolDefinition[],
  ): Promise<{ content?: string; toolCalls?: ToolCall[] }>;
}

// ============================================================================
// Message Conversion
// ============================================================================

/**
 * Convert ChatMessage to Ollama API format
 * Handles multimodal content (text + images)
 */
interface OllamaApiMessage {
  role: string;
  content: string;
  images?: string[];
  tool_name?: string;
}

function messageToOllamaFormat(msg: ChatMessage): OllamaApiMessage {
  // Handle tool messages - use the proper tool format
  if (msg.role === "tool") {
    return {
      role: "tool",
      content: msg.content,
      tool_name: msg.tool_name,
    };
  }

  // Handle regular messages
  let content: string;
  let images: string[] | undefined;

  if (typeof msg.content === "string") {
    content = msg.content;
    images = msg.images;
  } else if (Array.isArray(msg.content)) {
    // Multimodal content - extract text parts, images are handled separately
    const textParts: string[] = [];
    images = [];
    for (const block of msg.content) {
      if (block.type === "text") {
        textParts.push(block.text);
      } else if (block.type === "image") {
        // For ChatMessageImage blocks, use the data directly
        images.push(block.data);
      }
    }
    content = textParts.join("\n");
    // If we also have images from the message property, append them
    if (msg.images && msg.images.length > 0) {
      images = [...images, ...msg.images];
    }
  } else {
    content = "";
    images = msg.images;
  }

  return {
    role: msg.role,
    content,
    images: images && images.length > 0 ? images : undefined,
  };
}

// ============================================================================
// Ollama Provider
// ============================================================================

export class OllamaProvider implements LLMProvider {
  private config: OllamaConfig;
  private client: Ollama;

  constructor(config: OllamaConfig) {
    this.config = config;
    this.client = new Ollama({ host: config.baseUrl });
  }

  /**
   * Make a chat completion request to Ollama using the official library
   */
  async complete(messages: ChatMessage[]): Promise<string> {
    console.log(`[LLM] Request to ${this.config.model}`);
    console.log(`[LLM] Messages count: ${messages.length}`);

    // Log each message and detect images
    let totalImages = 0;
    for (let i = 0; i < messages.length; i++) {
      const msg = messages[i];
      const ollamaMsg = messageToOllamaFormat(msg);

      // Log image count
      if (ollamaMsg.images && ollamaMsg.images.length > 0) {
        totalImages += ollamaMsg.images.length;
        console.log(
          `[LLM]   [${i + 1}/${messages.length}] ${msg.role}: ${ollamaMsg.images.length} image(s)`,
        );
      } else {
        const preview = ollamaMsg.content.slice(0, 100).replace(/\n/g, " ");
        console.log(
          `[LLM]   [${i + 1}/${messages.length}] ${msg.role}: ${preview}${ollamaMsg.content.length > 100 ? "..." : ""}`,
        );
      }
    }

    if (totalImages > 0) {
      console.log(`[LLM] Total images in request: ${totalImages}`);
    }

    // Convert messages to Ollama format
    const ollamaMessages = messages.map(messageToOllamaFormat);

    try {
      const response = await this.client.chat({
        model: this.config.model,
        messages: ollamaMessages,
        stream: false,
        options: {
          temperature: this.config.temperature ?? 0.7,
          num_predict: this.config.maxTokens ?? 2048,
        },
      });

      const content = response.message?.content || "";

      console.log(
        `[LLM] Response: ${content.slice(0, 200)}${content.length > 200 ? "..." : ""}`,
      );
      return content;
    } catch (error) {
      console.error(`[LLM] Ollama API error: ${error}`);
      throw new Error(`Ollama API error: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Complete with tool calling support using the official Ollama library
   */
  async completeWithTools(
    messages: ChatMessage[],
    tools: ToolDefinition[],
  ): Promise<{ content?: string; toolCalls?: ToolCall[] }> {
    console.log(`[LLM] Tool request to ${this.config.model}`);
    console.log(`[LLM] Messages: ${messages.length}, Tools: ${tools.length}`);

    // Log tools being sent
    for (const tool of tools) {
      console.log(`[LLM]   Tool: ${tool.name} - ${tool.description}`);
    }

    // Log messages with image detection
    let totalImages = 0;
    for (let i = 0; i < messages.length; i++) {
      const msg = messages[i];
      const ollamaMsg = messageToOllamaFormat(msg);
      if (ollamaMsg.images && ollamaMsg.images.length > 0) {
        totalImages += ollamaMsg.images.length;
        console.log(
          `[LLM]   [${i + 1}/${messages.length}] ${msg.role}: ${ollamaMsg.images.length} image(s)`,
        );
      }
    }
    if (totalImages > 0) {
      console.log(`[LLM] Total images in request: ${totalImages}`);
    }

    // Convert messages to Ollama format
    const ollamaMessages = messages.map(messageToOllamaFormat);

    // Log full prompt (text only)
    const combinedPrompt = ollamaMessages
      .map((m) => `[${m.role}] ${m.content}`)
      .join("\n");
    console.log(
      `[LLM] Full prompt:\n${combinedPrompt.slice(0, 500)}${combinedPrompt.length > 500 ? "\n..." : ""}`,
    );

    // Convert tools to Ollama format
    const ollamaTools = tools.map((t) => ({
      type: "function" as const,
      function: {
        name: t.name,
        description: t.description,
        parameters: t.parameters,
      },
    }));

    try {
      console.log(`[LLM] Sending request to Ollama at ${this.config.baseUrl}`);

      let response;
      try {
        response = await this.client.chat({
          model: this.config.model,
          messages: ollamaMessages,
          tools: ollamaTools,
          stream: false,
          options: {
            temperature: this.config.temperature ?? 0.5, // Low temp for reliable tool calls
            num_predict: this.config.maxTokens ?? 4096,
          },
        });
      } catch (apiError) {
        // Try to extract more information from the error
        console.error(`[LLM] Ollama API call failed: ${apiError}`);

        // Check if it's a response parsing error
        const errorMsg = String(apiError);
        if (errorMsg.includes("invalid character") || errorMsg.includes("JSON")) {
          console.error(`[LLM] The Ollama server returned a malformed JSON response.`);
          console.error(`[LLM] This may indicate:`);
          console.error(`[LLM]   1. The model output malformed content`);
          console.error(`[LLM]   2. Ollama server version mismatch`);
          console.error(`[LLM]   3. Network corruption`);
          console.error(`[LLM]   4. Model running out of context window`);
        }

        throw new Error(`Ollama API error: ${apiError instanceof Error ? apiError.message : String(apiError)}`);
      }

      const message = response.message || { content: "", tool_calls: [] };
      const messageContent = message.content || "";

      // Safely log the response - handle circular references or malformed JSON
      let rawResponseLog: string;
      try {
        rawResponseLog = JSON.stringify(response);
      } catch {
        rawResponseLog = `[Response type: ${typeof response}, content preview: ${String(response).slice(0, 200)}]`;
      }
      console.log(`[LLM] Raw response: ${rawResponseLog.slice(0, 300)}...`);

      let toolCalls: ToolCall[] = [];

      // Try native tool_calls array format first
      if (message.tool_calls) {
        console.log(
          `[LLM] Tool calls detected (native format): ${message.tool_calls.length}`,
        );
        try {
          toolCalls = parseNativeToolCalls(message.tool_calls);
        } catch (toolParseError) {
          console.error(`[LLM] Failed to parse tool calls: ${toolParseError}`);
          // Try to recover by parsing the raw content
          toolCalls = tryParseToolCallsFromContent(messageContent);
        }
      }

      if (toolCalls.length > 0) {
        console.log(`[LLM] Returning ${toolCalls.length} tool call(s)`);
        return { toolCalls };
      }

      console.log(
        `[LLM] Response: ${messageContent.slice(0, 200)}${messageContent.length > 200 ? "..." : ""}`,
      );
      return { content: messageContent };
    } catch (error) {
      console.error(`[LLM] Ollama API error: ${error}`);
      throw new Error(`Ollama API error: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
}

/**
 * Parse tool calls from Ollama's native tool_calls array format
 */
function parseNativeToolCalls(
  toolCalls: Array<{ function: { name: string; arguments: unknown } }>,
): ToolCall[] {
  const result: ToolCall[] = [];

  for (const tc of toolCalls) {
    console.log(`[LLM]   Tool: ${tc.function.name}`);
    // Arguments can be either an object, a JSON string, or malformed JSON
    let args: Record<string, unknown> = {};
    if (tc.function.arguments) {
      if (typeof tc.function.arguments === "string") {
        try {
          args = JSON.parse(tc.function.arguments);
        } catch (parseError) {
          console.warn(`[LLM] Failed to parse tool arguments as JSON: ${parseError}`);
          console.warn(`[LLM] Raw arguments: ${tc.function.arguments}`);
          // Try to fix common JSON errors
          const fixedJson = fixCommonJsonErrors(tc.function.arguments);
          try {
            args = JSON.parse(fixedJson);
            console.log(`[LLM] Recovered arguments after fixing JSON errors`);
          } catch {
            // Last resort: treat as empty object
            args = {};
          }
        }
      } else if (typeof tc.function.arguments === "object") {
        args = tc.function.arguments as Record<string, unknown>;
      }
    }
    console.log(`[LLM]   Args: ${JSON.stringify(args)}`);
    result.push({
      type: "tool_call",
      name: tc.function.name,
      args,
      callId: crypto.randomUUID(),
    });
  }

  return result;
}

/**
 * Attempt to fix common JSON formatting errors in tool arguments
 */
function fixCommonJsonErrors(jsonStr: string): string {
  let fixed = jsonStr;

  // Fix trailing commas before closing braces/brackets
  fixed = fixed.replace(/,(\s*[}\]])/g, '$1');

  // Fix missing quotes around keys
  fixed = fixed.replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)(\s*:)/g, '$1"$2"$3');

  // Fix unquoted string values that look like identifiers
  fixed = fixed.replace(/:\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*([,}\]])/g, ': "$1"$2');

  // Remove control characters that might cause parsing issues
  fixed = fixed.replace(/[\x00-\x1f\x7f]/g, '');

  return fixed;
}

/**
 * Try to parse tool calls from content string when native parsing fails
 * Handles malformed JSON by attempting recovery strategies
 */
function tryParseToolCallsFromContent(content: string): ToolCall[] {
  const result: ToolCall[] = [];

  // Try to find JSON-like structures in the content
  const jsonMatch = content.match(/\{[\s\S]*?"tool_calls"[\s\S]*?\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed.tool_calls && Array.isArray(parsed.tool_calls)) {
        for (const tc of parsed.tool_calls) {
          result.push({
            type: "tool_call",
            name: tc.function?.name || tc.name || "unknown",
            args: tc.function?.arguments || tc.arguments || {},
            callId: crypto.randomUUID(),
          });
        }
      }
    } catch {
      // Failed to parse, continue with other strategies
    }
  }

  // Try to find individual tool call blocks like { "name": "...", "arguments": {...} }
  const toolBlockRegex = /\{"\s*"name"\s*:\s*"([^"]+)"\s*,\s*"arguments"\s*:\s*(\{[\s\S]*?\})\s*\}/g;
  let match;
  while ((match = toolBlockRegex.exec(content)) !== null) {
    try {
      const args = JSON.parse(match[2]);
      result.push({
        type: "tool_call",
        name: match[1],
        args,
        callId: crypto.randomUUID(),
      });
    } catch {
      // Skip malformed tool call blocks
    }
  }

  if (result.length > 0) {
    console.log(`[LLM] Recovered ${result.length} tool call(s) from content`);
  }

  return result;
}

// Tool registry entry: combines schema (ToolDefinition) with handler
type ToolRegistryEntry = {
  schema: ToolDefinition;
  handler: (
    args: Record<string, unknown>,
    deps: ToolDependencies,
  ) => Promise<ToolResult>;
};

type ToolDependencies = {
  chromaStore?: import("../chroma/client.js").ChromaMemoryStore;
  discordApiClient: DiscordApiClient;
};

/**
 * Single source of truth for all tools.
 * Prevents drift between tool definitions (schema) and implementations (handler).
 */
const TOOL_REGISTRY: Record<string, ToolRegistryEntry> = {
  "memory.lookup": {
    schema: {
      name: "memory.lookup",
      description:
        "Semantic search for memories in the database using a query string. Returns relevant memories with similarity scores. Ask natural language questions.",
      parameters: {
        type: "object",
        properties: {
          query: {
            type: "string",
            description: "The search query to find relevant memories",
          },
          limit: {
            type: "number",
            description: "Maximum number of memories to return (default: 5)",
          },
        },
        required: ["query"],
      },
    },
    handler: async (args, deps) => {
      const { query, limit = 5 } = args as { query: string; limit: number };

      console.log(`[TOOL] memory.lookup called`);
      console.log(`[TOOL]   query: "${query}"`);
      console.log(`[TOOL]   limit: ${limit}`);

      let results: Array<{ id: string; content: string; similarity: number }> =
        [];

      try {
        if (deps.chromaStore) {
          const searchResults = await deps.chromaStore.search(query, { limit });
          results = searchResults.map((r) => ({
            id: r.id,
            content: r.content,
            similarity: r.distance,
          }));
          console.log(`[TOOL]   Found ${results.length} memories from Chroma`);
        }

        return {
          toolName: "memory.lookup",
          success: true,
          result: {
            query,
            limit,
            results,
            note: results.length === 0 ? "No matches found" : undefined,
          },
        };
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        console.error(`[TOOL] memory.lookup failed: ${errorMsg}`);
        return {
          toolName: "memory.lookup",
          success: false,
          error: errorMsg,
        };
      }
    },
  },

  "memory.pin": {
    schema: {
      name: "memory.pin",
      description:
        "Pin a memory to keep it in the context window. Use memory.lookup to find memory IDs",
      parameters: {
        type: "object",
        properties: {
          memory_id: {
            type: "string",
            description: "The ID of the memory to pin",
          },
          priority: {
            type: "number",
            description: "Priority level for the pinned memory (default: 10)",
          },
        },
        required: ["memory_id"],
      },
    },
    handler: async (args) => {
      const { memory_id, priority = 10 } = args as {
        memory_id: string;
        priority: number;
      };

      console.log(`[TOOL] memory.pin called`);
      console.log(`[TOOL]   memory_id: ${memory_id}`);
      console.log(`[TOOL]   priority: ${priority}`);

      return {
        toolName: "memory.pin",
        success: true,
        result: { memory_id, priority, pinned: true },
      };
    },
  },

  "discord.channel.messages": {
    schema: {
      name: "discord.channel.messages",
      description:
        "Fetch messages from a Discord channel. CRITICAL: You MUST use discord.list.channels FIRST to discover available channels. Do NOT guess channel IDs - you will get 'Missing Access' errors. If you receive 'Missing Access', use one of the channels returned in available_channels.",
      parameters: {
        type: "object",
        properties: {
          channel_id: {
            type: "string",
            description:
              "The Discord channel ID. CRITICAL: Call discord.list.channels FIRST to get valid IDs. Guessing will fail with 'Missing Access'.",
          },
          limit: {
            type: "number",
            description:
              "Maximum number of messages to fetch (default: 50, max: 100)",
          },
          before: {
            type: "string",
            description: "Fetch messages before this message ID",
          },
          after: {
            type: "string",
            description: "Fetch messages after this message ID",
          },
          around: {
            type: "string",
            description: "Fetch messages around this message ID",
          },
        },
        required: ["channel_id"],
      },
    },
    handler: async (args, deps) => {
      const {
        channel_id,
        limit = 50,
        before,
        after,
        around,
      } = args as {
        channel_id: string;
        limit?: number;
        before?: string;
        after?: string;
        around?: string;
      };

      try {
        const result = await deps.discordApiClient.fetchChannelMessages(
          channel_id,
          {
            limit,
            before,
            after,
            around,
          },
        );

        // [ImageLogger] Log images found in channel messages
        let totalImages = 0;
        const imageTypes: Record<string, number> = {};

        for (const msg of result.messages) {
          if (msg.attachments && msg.attachments.length > 0) {
            for (const att of msg.attachments) {
              const isImage =
                att.contentType?.startsWith("image/") ||
                /\.(jpg|jpeg|png|gif|webp|bmp|webp|avif)$/i.test(
                  att.filename || "",
                );

              if (isImage) {
                totalImages++;
                const ext = (att.filename?.split(".").pop()?.toLowerCase() ||
                  att.contentType?.split("/")[1] ||
                  "unknown") as string;
                imageTypes[ext] = (imageTypes[ext] || 0) + 1;

                console.log(
                  `[ImageLogger] discord.channel.messages found image: <${att.contentType || "unknown"}> ${att.filename || "unnamed"} URL: ${att.url}`,
                );
              }
            }
          }

          // Also check embeds for images (rich media)
          // Cast embeds to extended DiscordEmbed type for thumbnail/image access
          const embeds = msg.embeds as Array<{
            type?: string;
            thumbnail?: { url?: string };
            image?: { url?: string };
          }>;

          if (embeds && embeds.length > 0) {
            for (const embed of embeds) {
              if (embed.type === "image" || embed.type === "gifv") {
                totalImages++;
                const ext = embed.type === "gifv" ? "gif" : "embed_image";
                imageTypes[ext] = (imageTypes[ext] || 0) + 1;
                console.log(
                  `[ImageLogger] discord.channel.messages found embed image: <${embed.type}>`,
                );
              }
              // Check thumbnail in non-image embeds
              if (embed.thumbnail?.url && embed.type !== "image") {
                totalImages++;
                imageTypes["thumbnail"] = (imageTypes["thumbnail"] || 0) + 1;
                console.log(
                  `[ImageLogger] discord.channel.messages found embed thumbnail: ${embed.thumbnail.url}`,
                );
              }
              // Check for images in embed.image property
              if (embed.image?.url) {
                totalImages++;
                imageTypes["embed_image"] =
                  (imageTypes["embed_image"] || 0) + 1;
                console.log(
                  `[ImageLogger] discord.channel.messages found embed.image: ${embed.image.url}`,
                );
              }
            }
          }
        }

        if (totalImages > 0) {
          console.log(
            `[ImageLogger] discord.channel.messages summary: ${totalImages} total images found`,
          );
          console.log(
            `[ImageLogger] Breakdown by type: ${JSON.stringify(imageTypes)}`,
          );
        } else {
          console.log(
            `[ImageLogger] discord.channel.messages: No images found in ${result.messages.length} messages`,
          );
        }

        return {
          toolName: "discord.channel.messages",
          success: true,
          result: { messages: result.messages, count: result.count },
        };
      } catch (error) {
        // On error, return available channels so the LLM can discover correct ones
        let accessibleChannels: Array<{
          id: string;
          name: string;
          guildId: string;
          type: string;
        }> = [];
        try {
          const channelsResult = await deps.discordApiClient.listChannels();
          accessibleChannels = channelsResult.channels;
        } catch {
          // Best effort - if we can't list channels, just return the error
        }

        return {
          toolName: "discord.channel.messages",
          success: false,
          error: error instanceof Error ? error.message : String(error),
          available_channels: accessibleChannels,
          available_channels_count: accessibleChannels.length,
          hint:
            accessibleChannels.length > 0
              ? "Channel not accessible. Use one of the available_channels above. Call discord.list.channels to get more details."
              : "No accessible channels found. Make sure the bot is in the server and has proper permissions.",
        };
      }
    },
  },

  "discord.channel.scroll": {
    schema: {
      name: "discord.channel.scroll",
      description:
        "Scroll through channel messages (sugar over messages with before=oldest-seen-id). Use discord.list.channels to find a channel",
      parameters: {
        type: "object",
        properties: {
          channel_id: {
            type: "string",
            description: "The Discord channel ID to scroll through",
          },
          oldest_seen_id: {
            type: "string",
            description:
              "The oldest message ID already seen - fetch messages before this",
          },
          limit: {
            type: "number",
            description:
              "Maximum number of messages to fetch (default: 50, max: 100)",
          },
        },
        required: ["channel_id", "oldest_seen_id"],
      },
    },
    handler: async (args, deps) => {
      const {
        channel_id,
        oldest_seen_id,
        limit = 50,
      } = args as {
        channel_id: string;
        oldest_seen_id: string;
        limit?: number;
      };

      try {
        const result = await deps.discordApiClient.scrollChannelMessages(
          channel_id,
          oldest_seen_id,
          limit,
        );
        return {
          toolName: "discord.channel.scroll",
          success: true,
          result: {
            messages: result.messages,
            count: result.count,
            oldest_seen_id,
          },
        };
      } catch (error) {
        return {
          toolName: "discord.channel.scroll",
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    },
  },

  "discord.dm.messages": {
    schema: {
      name: "discord.dm.messages",
      description: "Fetch messages from a DM channel with a user",
      parameters: {
        type: "object",
        properties: {
          user_id: {
            type: "string",
            description: "The Discord user ID to open DM with",
          },
          limit: {
            type: "number",
            description:
              "Maximum number of messages to fetch (default: 50, max: 100)",
          },
          before: {
            type: "string",
            description: "Fetch messages before this message ID",
          },
        },
        required: ["user_id"],
      },
    },
    handler: async (args, deps) => {
      const {
        user_id,
        limit = 50,
        before,
      } = args as {
        user_id: string;
        limit?: number;
        before?: string;
      };

      try {
        const result = await deps.discordApiClient.fetchDMMessages(user_id, {
          limit,
          before,
        });
        return {
          toolName: "discord.dm.messages",
          success: true,
          result: {
            messages: result.messages,
            count: result.count,
            dm_channel_id: result.dmChannelId,
          },
        };
      } catch (error) {
        return {
          toolName: "discord.dm.messages",
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    },
  },

  "discord.search": {
    schema: {
      name: "discord.search",
      description:
        "Search messages in a Discord channel or DM. Supports filtering by query text and user ID. Falls back to client-side filtering if native search unavailable.",
      parameters: {
        type: "object",
        properties: {
          scope: {
            type: "string",
            description: 'Search scope: "channel" or "dm"',
            enum: ["channel", "dm"],
          },
          channel_id: {
            type: "string",
            description: "Channel ID to search (required if scope=channel)",
          },
          user_id: {
            type: "string",
            description: "User ID for DM search (required if scope=dm)",
          },
          query: {
            type: "string",
            description: "Optional text to search for in message content",
          },
          limit: {
            type: "number",
            description: "Maximum results to return (default: 50, max: 100)",
          },
          before: {
            type: "string",
            description: "Fetch messages before this message ID",
          },
          after: {
            type: "string",
            description: "Fetch messages after this message ID",
          },
        },
        required: ["scope"],
      },
    },
    handler: async (args, deps) => {
      const {
        scope,
        channel_id,
        user_id,
        query,
        limit = 50,
        before,
        after,
      } = args as {
        scope: "channel" | "dm";
        channel_id?: string;
        user_id?: string;
        query?: string;
        limit?: number;
        before?: string;
        after?: string;
      };

      try {
        const result = await deps.discordApiClient.searchMessages(scope, {
          channelId: channel_id,
          userId: user_id,
          query,
          limit,
          before,
          after,
        });
        return {
          toolName: "discord.search",
          success: true,
          result: {
            messages: result.messages,
            count: result.count,
            source: result.source,
          },
        };
      } catch (error) {
        return {
          toolName: "discord.search",
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    },
  },

  "discord.send": {
    schema: {
      name: "discord.send",
      description:
        "Send a message to a Discord channel from discord.list.channels.",
      parameters: {
        type: "object",
        properties: {
          channel_id: {
            type: "string",
            description:
              "The Discord channel ID to send the message to. Obtained from discord.list.channels",
          },
          text: {
            type: "string",
            description: "The message text to send",
          },
          reply_to: {
            type: "string",
            description: "Optional message ID to reply to",
          },
        },
        required: ["channel_id", "text"],
      },
    },
    handler: async (args, deps) => {
      const { channel_id, text, reply_to } = args as {
        channel_id: string;
        text: string;
        reply_to?: string;
      };

      try {
        const result = await deps.discordApiClient.sendMessage(
          channel_id,
          text,
          reply_to,
        );
        return {
          toolName: "discord.send",
          success: true,
          result: {
            messageId: result.messageId,
            channel_id: result.channelId,
            sent: result.sent,
            timestamp: result.timestamp,
          },
        };
      } catch (error) {
        return {
          toolName: "discord.send",
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    },
  },

  "discord.list.servers": {
    schema: {
      name: "discord.list.servers",
      description:
        "List all Discord servers/guilds the bot is a member of. Use this BEFORE discord.list.channels",
      parameters: {
        type: "object",
        properties: {},
        required: [],
      },
    },
    handler: async (_args, deps) => {
      try {
        const result = await deps.discordApiClient.listServers();
        return {
          toolName: "discord.list.servers",
          success: true,
          result: { servers: result.servers, count: result.count },
        };
      } catch (error) {
        return {
          toolName: "discord.list.servers",
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    },
  },

  "discord.list.channels": {
    schema: {
      name: "discord.list.channels",
      description: "List all channels in a Discord server/guild",
      parameters: {
        type: "object",
        properties: {
          guild_id: {
            type: "string",
            description: `The Discord guild/server ID to list channels for (optional - if not provided, lists all accessible channels).
              Don't guess, use discord.list.servers first.
`,
          },
        },
        required: [],
      },
    },
    handler: async (args, deps) => {
      const { guild_id } = args as { guild_id?: string };

      try {
        const result = await deps.discordApiClient.listChannels(guild_id);
        return {
          toolName: "discord.list.channels",
          success: true,
          result: { channels: result.channels, count: result.count },
        };
      } catch (error) {
        return {
          toolName: "discord.list.channels",
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    },
  },

  get_current_time: {
    schema: {
      name: "get_current_time",
      description: "Get the current timestamp and ISO date",
      parameters: {
        type: "object",
        properties: {},
        required: [],
      },
    },
    handler: async () => {
      return {
        toolName: "get_current_time",
        success: true,
        result: { timestamp: Date.now(), iso: new Date().toISOString() },
      };
    },
  },
};

/**
 * Tool executor that handles tool calls
 */
export class ToolExecutor {
  private tools: Map<
    string,
    (args: Record<string, unknown>) => Promise<ToolResult>
  > = new Map();
  private eventBus: InMemoryEventBus;
  private chromaStore?: import("../chroma/client.js").ChromaMemoryStore;
  private discordApiClient: DiscordApiClient;

  constructor(
    eventBus: InMemoryEventBus,
    chromaStore?: import("../chroma/client.js").ChromaMemoryStore,
    discordApiClient?: DiscordApiClient,
  ) {
    this.eventBus = eventBus;
    this.chromaStore = chromaStore;
    if (!discordApiClient) {
      throw new Error(
        "DiscordApiClient is required. Pass a single shared instance from main.ts",
      );
    }
    this.discordApiClient = discordApiClient;
    this.registerDefaultTools();
  }

  setDiscordClient(client: import("discord.js").Client): void {
    this.discordApiClient.setClient(client);
  }

  /**
   * Register a tool handler
   */
  registerTool(
    name: string,
    handler: (args: Record<string, unknown>) => Promise<ToolResult>,
  ): void {
    this.tools.set(name, handler);
  }

  async execute(toolCall: ToolCall, sessionId?: string): Promise<ToolResult> {
    const handler = this.tools.get(toolCall.name);

    console.log(`[TOOL] Executing: ${toolCall.name}`);
    console.log(`[TOOL]   callId: ${toolCall.callId}`);
    console.log(`[TOOL]   sessionId: ${sessionId || "none"}`);
    console.log(`[TOOL]   args: ${JSON.stringify(toolCall.args)}`);

    if (!handler) {
      console.error(`[TOOL] Unknown tool: ${toolCall.name}`);
      return {
        toolName: toolCall.name,
        success: false,
        error: `Unknown tool: ${toolCall.name}`,
      };
    }

    try {
      console.log(`[TOOL] Running handler for ${toolCall.name}...`);
      const startTime = Date.now();
      const result = await handler(toolCall.args);
      const duration = Date.now() - startTime;

      console.log(`[TOOL] ${toolCall.name} completed in ${duration}ms`);
      console.log(`[TOOL]   success: ${result.success}`);
      if (result.success && result.result) {
        console.log(
          `[TOOL]   result: ${JSON.stringify(result.result).slice(0, 200)}${JSON.stringify(result.result).length > 200 ? "..." : ""}`,
        );
      }
      if (!result.success && result.error) {
        console.log(`[TOOL]   error: ${result.error}`);
      }

      await this.eventBus.publish("tool.result", {
        toolName: toolCall.name,
        callId: toolCall.callId,
        sessionId,
        result: result.result,
        error: result.error,
      });

      return result;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      console.error(`[TOOL] ${toolCall.name} failed: ${errorMsg}`);
      const result = {
        toolName: toolCall.name,
        success: false,
        error: errorMsg,
      };

      await this.eventBus.publish("tool.result", {
        toolName: toolCall.name,
        callId: toolCall.callId,
        sessionId,
        result: undefined,
        error: result.error,
      });

      return result;
    }
  }

  /**
   * Get all registered tool definitions for the LLM
   * Uses tool definitions from prompts module to prevent schema/handler drift
   */
  getToolDefinitions(): ToolDefinition[] {
    return getAllToolDefinitions();
  }

  /**
   * Register default tools from TOOL_REGISTRY
   * Wraps handlers to inject dependencies (chromaStore, discordApiClient)
   */
  private registerDefaultTools(): void {
    const deps: ToolDependencies = {
      chromaStore: this.chromaStore,
      discordApiClient: this.discordApiClient,
    };

    const toolAliases: Record<string, string> = {
      // LLM may generate singular form, but tools are registered with plural
      "discord.channel.message": "discord.channel.messages",
    };

    for (const [name, entry] of Object.entries(TOOL_REGISTRY)) {
      this.registerTool(name, (args) => entry.handler(args, deps));
    }

    // Register tool aliases for common typos/variations
    for (const [alias, actual] of Object.entries(toolAliases)) {
      if (TOOL_REGISTRY[actual]) {
        this.registerTool(alias, (args) =>
          TOOL_REGISTRY[actual].handler(args, deps),
        );
      }
    }
  }
}

/**
 * Turn processor that orchestrates LLM calls and tool execution
 */
export class TurnProcessor {
  private provider: LLMProvider;
  private executor: ToolExecutor;
  private memoryStore: MemoryStore;
  private eventBus: EventBus;
  private policy: CephalonPolicy;
  private discordApiClient: DiscordApiClient;

  constructor(
    provider: LLMProvider,
    executor: ToolExecutor,
    memoryStore: MemoryStore,
    eventBus: EventBus,
    policy: CephalonPolicy,
    discordApiClient: DiscordApiClient,
  ) {
    this.provider = provider;
    this.executor = executor;
    this.memoryStore = memoryStore;
    this.eventBus = eventBus;
    this.policy = policy;
    this.discordApiClient = discordApiClient;
  }

  /**
   * Get the executor for direct tool calls (used by proactive behavior)
   */
  getExecutor(): ToolExecutor {
    return this.executor;
  }

  /**
   * Process a turn: receive event, assemble context, call LLM, execute tools
   * Implements the proper tool-calling loop as per Ollama's agent pattern
   */
  async processTurn(session: Session, event: CephalonEvent): Promise<void> {
    console.log(`[TurnProcessor] Processing turn for session ${session.id}`);

    // Validate inputs
    if (!event || typeof event !== "object") {
      console.error(
        `[TurnProcessor] Error: event is undefined or not an object`,
      );
      return;
    }
    if (!event.type) {
      console.error(`[TurnProcessor] Error: event.type is undefined`);
      return;
    }

    // Mint memory from the user's message
    const mintingConfig = {
      cephalonId: session.cephalonId,
      sessionId: session.id,
      schemaVersion: 1,
    };

    try {
      // Mint memory from the Discord event (user message)
      if (event.type.startsWith("discord.")) {
        await mintFromDiscordEvent(this.memoryStore, event, mintingConfig);
      }

      // Assemble context
      const tokenizer = createHeuristicTokenizer();
      const context = await assembleContext({
        windowTokens: this.policy.models.actor.maxContextTokens,
        policy: this.policy,
        session,
        currentEvent: event,
        tokenizer,
        memoryStore: this.memoryStore,
        retrieveRelated: async () => [], // TODO: Implement vector retrieval
      });

      // Build conversation history for tool loop
      const messages: import("../types/index.js").ChatMessage[] = [
        ...context.messages,
      ];
      const tools = this.executor.getToolDefinitions();

      // For tick events, add the entertainment persona header
      if (event.type === "system.tick") {
        const tickPayload = event.payload as {
          intervalMs: number;
          tickNumber: number;
          reflectionPrompt?: string;
          recentActivity?: Array<{
            type: string;
            preview: string;
            timestamp?: number;
          }>;
        };

        // Generate entertainment persona header
        const personaHeader = generatePersonaHeader(
          tickPayload.tickNumber,
          tickPayload.recentActivity
        );

        if (personaHeader) {
          messages.push(personaHeader);
          console.log(
            `[TurnProcessor] Persona: ${getCurrentPersonaName(tickPayload.tickNumber)}`
          );
        }

        // Add user message with reflection prompt
        messages.push({
          role: "user" as const,
          content: tickPayload.reflectionPrompt || "Respond naturally in this persona.",
        });
      }

      // Tool-calling loop: continue until no more tool calls
      let maxIterations = 10; // Prevent infinite loops
      let finalContent: string | undefined;
      let loopError: string | undefined;

      while (maxIterations-- > 0) {
        console.log(
          `[TurnProcessor] LLM call (iteration ${10 - maxIterations})`,
        );

        let result: { content?: string; toolCalls?: import("../types/index.js").ToolCall[] };
        try {
          // Call LLM with current conversation history
          result = await this.provider.completeWithTools(messages, tools);
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          console.error(`[TurnProcessor] LLM call failed: ${errorMsg}`);
          loopError = errorMsg;
          break; // Exit the loop on error
        }

        // If the model returned tool calls, execute them
        if (result.toolCalls && result.toolCalls.length > 0) {
          console.log(
            `[TurnProcessor] Executing ${result.toolCalls.length} tool call(s)`,
          );

          // Create assistant message with tool_calls for the history
          const assistantMessage: import("../types/index.js").ChatMessage = {
            role: "assistant",
            content: result.content || "",
            tool_calls: result.toolCalls.map(
              (tc): import("../types/index.js").OllamaToolCall => ({
                type: "function",
                function: {
                  name: tc.name,
                  arguments: tc.args,
                },
              }),
            ),
          };
          messages.push(assistantMessage);

          // Execute each tool call and append results to history
          for (const toolCall of result.toolCalls) {
            const toolResult = await this.executor.execute(
              toolCall,
              session.id,
            );
            console.log(
              `[TurnProcessor] Tool ${toolCall.name}:`,
              toolResult.success ? "success" : toolResult.error,
            );

            // Append tool result to conversation history (Ollama format: role="tool", tool_name, content)
            const toolResultMessage: import("../types/index.js").ChatMessage = {
              role: "tool",
              tool_name: toolCall.name,
              content: toolResult.success
                ? JSON.stringify(toolResult.result ?? null)
                : JSON.stringify({
                    error: toolResult.error ?? "unknown error",
                  }),
            };
            messages.push(toolResultMessage);

            // Mint memories for tool call and result
            await mintFromToolCall(
              this.memoryStore,
              {
                toolName: toolCall.name,
                args: toolCall.args,
                callId: crypto.randomUUID(),
              },
              {
                toolName: toolCall.name,
                callId: toolCall.callId,
                result: toolResult.result,
                error: toolResult.error,
              },
              mintingConfig,
              {
                eventId: event.id,
                timestamp: Date.now(),
              },
            );
          }

          // Continue the loop to get final response from LLM
          continue;
        }

        // No more tool calls - this is the final response
        finalContent = result.content;
        console.log(
          `[TurnProcessor] Final response: ${finalContent?.slice(0, 100) ?? "(empty)"}...`,
        );
        break;
      }

      if (maxIterations <= 0) {
        console.warn(`[TurnProcessor] Tool loop hit max iterations, stopping`);
      } else if (loopError) {
        console.warn(`[TurnProcessor] Tool loop stopped due to error: ${loopError}`);
      }

      // Skip final processing if there was an error
      if (loopError || !finalContent) {
        return;
      }

      // Mint memory from the final LLM response
      if (finalContent) {
        await mintFromLLMResponse(
          this.memoryStore,
          finalContent,
          mintingConfig,
        );

        // Output to configured channel with feedback loop prevention
        const outputConfig = this.policy.output;
        const targetChannelId = outputConfig?.defaultChannelId;

        if (targetChannelId) {
          // Check for feedback loop: don't respond if event came from target channel or from ignored author
          const eventPayload = event.payload as {
            channelId?: string;
            authorId?: string;
            authorIsBot?: boolean;
          };
          const eventChannelId = eventPayload?.channelId;
          const eventAuthorId = eventPayload?.authorId;
          const isBot = eventPayload?.authorIsBot;

          const shouldSkipOutput =
            // Skip if event came from the same channel (prevent echo)
            eventChannelId === targetChannelId ||
            // Skip if author is in ignored list
            (eventAuthorId &&
              outputConfig?.ignoredAuthorIds?.includes(eventAuthorId)) ||
            // Skip if bot messages and feedback loop prevention enabled
            (outputConfig?.preventFeedbackLoops && isBot);

          if (shouldSkipOutput) {
            console.log(
              `[TurnProcessor] Skipping output to ${targetChannelId} (feedback loop prevention)`,
            );
          } else {
            try {
              await this.discordApiClient.sendMessage(
                targetChannelId,
                finalContent,
              );
            } catch (error) {
              const errorMsg =
                error instanceof Error ? error.message : String(error);
              console.error(
                `[TurnProcessor] Failed to send message to channel ${targetChannelId}: ${errorMsg}`,
              );
            }
          }
        }
      }

      // Log inclusion
      await this.memoryStore.logInclusion(context.inclusionLog);

      // Publish turn completed event for proactive behavior tracking
      const channelId =
        event.type.startsWith("discord.") || event.type === "system.proactive"
          ? (event.payload as { channelId?: string }).channelId
          : undefined;

      await this.eventBus.publish("session.turn.completed", {
        sessionId: session.id,
        eventType: event.type,
        channelId,
        timestamp: Date.now(),
      });
    } catch (error) {
      console.error(`[TurnProcessor] Error:`, error);
      await this.eventBus.publish("session.turn.error", {
        sessionId: session.id,
        error: error instanceof Error ? error.message : String(error),
        timestamp: Date.now(),
      });
    }
  }
}

export { createOllamaConfig } from "../config/defaults.js";
