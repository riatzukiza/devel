// AVA configuration for cephalon-ts
// Only runs tests within this package directory

export default {
  files: [
    'src/**/*.test.{js,ts,mjs,cjs}',
    '!**/node_modules/**',
    '!**/dist/**',
    '!**/build/**'
  ],
  extensions: {
    ts: 'module',
  },
  nodeArguments: [
    '--import=tsx',
    '--no-warnings',
  ],
  timeout: '2m',
  environmentVariables: {
    NODE_ENV: 'test',
  },
};
