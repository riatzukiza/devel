/** @const {ShadowJS} */ var module;
/** @const {ShadowJS} */ var setInterval;
ShadowJS.prototype.DISCORD_TOKEN;
ShadowJS.prototype.DUCK_DISCORD_TOKEN;
ShadowJS.prototype.OPENAI_API_KEY;
ShadowJS.prototype.OPENAI_BASE_URL;
ShadowJS.prototype.createCephalonApp;
ShadowJS.prototype.env;
ShadowJS.prototype.readFileSync;